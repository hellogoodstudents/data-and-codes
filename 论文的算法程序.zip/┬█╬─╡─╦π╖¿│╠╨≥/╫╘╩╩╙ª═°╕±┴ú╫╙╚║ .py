import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import math
import random
import scipy.stats as stats
import matplotlib as mpl
# 绘制三维图像和色图
from matplotlib import cm
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体，可显示中文
mpl.rcParams['axes.unicode_minus'] = False  # 正常显示图像中的负号
import time

a1 = 0.5 # 在全局作用域定义变量a1,目标函数系统工作时长的权重
a2 = 0.5  # 在全局作用域定义变量a2，目标函数干扰机成本的权重

boundaries = (0, 50000, 0, 50000)  # 定义搜索空间的边界
communication_number = 32     ##########  重复，未检验
jammer_number = 33


power_jammer = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60]


# 通信节点相关信息矩阵
communication = [
    [1, 2, 44700, 11400, 5, 0.61, -97.92],
    [2, 2, 47000, 18600, 5, 0.68, -100.42],
    [3, 1, 30600, 3700, 2200, 0.96, -99.22],
    [4, 1, 4700, 12200, 2800, 0.28, -103.94],
    [5, 1, 25600, 10000, 2400, 0.36, -99.22],
    [6, 1, 28300, 38100, 2600, 0.25, -98.41],
    [7, 1, 42300, 4600, 2300, 0.62, -96.96],
    [8, 1, 9400, 41500, 2800, 0.41, -101.49],
    [9, 1, 34300, 33500, 2600, 0.17, -98.41],
    [10, 1, 16000, 9800, 2400, 0.03, -101.52],
    [11, 1, 8900, 29600, 2300, 0.87, -104.34],
    [12, 1, 46700, 39300, 2100, 0.19, -103.12],
    [13, 3, 46200, 28300, 2, 0.21, -103.4],
    [14, 3, 19900, 200, 2, 0.4, -103.86],
    [15, 3, 34500, 7500, 2, 0.11, -96.12],
    [16, 3, 15600, 41200, 2, 0.26, -98.04],
    [17, 3, 34900, 47600, 2, 0.89, -105.27],
    [18, 3, 47600, 45200, 2, 0.85, -97.09],
    [19, 3, 8300, 2100, 2, 0.29, -104.39],
    [20, 3, 3100, 25300, 2, 0.02, -99.44],
    [21, 3, 18700, 41100, 2, 0.03, -102.68],
    [22, 3, 44400, 44900, 2, 0.06, -97.25],
    [23, 3, 42300, 43600, 2, 0.51, -97.44],
    [24, 3, 32900, 42100, 2, 0.19, -97.69],
    [25, 3, 11300, 100, 2, 0.56, -104.34],
    [26, 3, 39100, 43400, 2, 0.39, -101.51],
    [27, 3, 48400, 27700, 2, 0.49, -100.99],
    [28, 3, 47500, 28300, 2, 0.9, -100.99],
    [29, 3, 8800, 20000, 2, 0.5, -102.03],
    [30, 3, 5900, 36600, 2, 0.4, -97.72],
    [31, 3, 5000, 39500, 2, 0.48, -95.46],
    [32, 3, 400, 1300, 2, 0.79, -105.48],

]

Interference_distance = [
    [0, float('-inf'), 0, 0, 0, 0, 0],
    [3, 4.77, 10, 15, 20, 20, 20],
    [6, 7.78, 10, 15, 20, 20, 20],
    [9, 9.54, 10, 15, 20, 20, 20],
    [12, 10.79, 10, 15, 20, 20, 20],
    [15, 11.76, 10, 15, 20, 20, 20],
    [18, 12.55, 10, 15, 20, 20, 20],
    [21, 13.22, 10, 15, 20, 20, 20],
    [24, 13.8, 10, 15, 20, 20, 20],
    [27, 14.31, 10, 15, 20, 20, 20],
    [30, 14.77, 10, 15, 20, 20, 20],
    [33, 15.19, 10, 15, 20, 20, 20],
    [36, 15.56, 10, 15, 20, 20, 20],
    [39, 15.91, 10, 15, 20, 20, 20],
    [42, 16.23, 10, 15, 20, 20, 20],
    [45, 16.53, 10, 15, 20, 20, 20],
    [48, 16.81, 10, 15, 20, 20, 20],
    [51, 17.08, 10, 15, 20, 20, 20],
    [54, 17.32, 10, 15, 20, 20, 20],
    [57, 17.56, 10, 15, 20, 20, 20],
    [60, 17.78, 10, 15, 20, 20, 20],
]



# 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: (
    30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


# 限制条件1相关判断（判断干信比是否大于1，这里复用之前的代码逻辑）
def check_Conditions1(communications):
    #print('communications',communications)
    Conditions1 = 1  # 先假设所有行都满足条件，初始设为1
    for row in communications:
        #print(',row[7],row[6]',row[7],row[6])
        if row[7] == float('-inf') or row[7] - row[6] <= 4.77:
            #print(f"Row {row} does not meet Condition 1")
            Conditions1 = 0
            break  # 一旦发现有一行不满足条件，就将Conditions1设为0并结束循环
    return Conditions1


# 限制条件2相关判断（判断干扰机与通信节点距离是否大于500米，这里复用之前的代码逻辑）
def check_distance(communication, jammer):
    Conditions2 = 1  # 先假设所有行都满足条件，初始设为1
    #print('communication222222222',communication)
    #print('jammer222222', jammer)                      #########干扰机数量不对
    for jammer_info in jammer:
        jammer_x = jammer_info[2]
        jammer_y = jammer_info[3]
        jammer_z = jammer_info[4]
        for communication_info in communication:
            comm_x = communication_info[2]
            comm_y = communication_info[3]
            comm_z = communication_info[4]
            # 使用 numpy.linalg.norm 计算距离
            distance = np.linalg.norm(np.array([jammer_x - comm_x, jammer_y - comm_y, jammer_z - comm_z]))
            #print(f"Distance between jammer {jammer_info} and communication node {communication_info}: {distance} meters")
            if distance < 500:
                #print(f"Jammer {jammer_info} is too close to communication node {communication_info}")
                Conditions2 = 0
                return Conditions2
    return Conditions2


def generate_jammer_matrix(npop):
    all_interference_matrices = []
    for _ in range(npop):
        interference_matrix = []
        for i in range(1, jammer_number):  # 生成30行，可根据需要更改数量                干扰机数量jammer_number -1 0000000000000000000000
            row = []
            row.append(i)  # 序号
            is_airborne = random.randint(0, 1)  # 0或1，代表地面或空中干扰机
            row.append(is_airborne)
            x_coordinate = random.randint(0, 500) * 100  # x坐标，以100为栅格数值，取值在0到50000
            row.append(x_coordinate)
            y_coordinate = random.randint(0, 500) * 100  # y坐标，以100为栅格数值，取值在0到50000
            row.append(y_coordinate)
            if is_airborne == 0:
                height = 3
                power = random.randint(1, 20) * 3  # 地面干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
            else:
                height = random.randint(3, 20) * 100  # 空中干扰机高度，以100为间隔，取值在300到2000之间
                power = random.randint(1, 15) * 3  # 空中干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
            row.append(height)
            row.append(power)
            interference_matrix.append(row)
        all_interference_matrices.append(interference_matrix)
    return all_interference_matrices


def reprocess_interference(jammers):
    all_communication_copies = []
    for jammer in jammers:
        communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作
        for jammer_row in jammer:
            jammer_type = jammer_row[1]
            jammer_power_W = jammer_row[5]
            jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

            for communication_row in communication_copy:
                communication_type = communication_row[1]
                x_distance = abs(jammer_row[2] - communication_row[2])
                y_distance = abs(jammer_row[3] - communication_row[3])
                z_distance = abs(jammer_row[4] - communication_row[4])
                distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
                distance = round(distance, 2)

                interference_distance = None
                Gtr = None
                h_t = None
                h_r = None
                Lc_j = None

                if jammer_type == 0 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][2]
                    Gtr = 3
                    h_t = 3
                    h_r = 2
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 0 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][3]
                    Gtr = 4.5
                    h_t = 3
                    h_r = 5
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 1 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][4]
                    Gtr = 3
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 0 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][6]
                    Gtr = 4.5
                    Lc_j = L_sight(distance)

                if interference_distance is not None and distance <= interference_distance:
                    interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                    interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW!= float('-inf') else 0
                    if len(communication_row) < 8:
                        communication_row.append(interference_power_W + 3.16e-12)
                    else:
                        if len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                            communication_row[7] += interference_power_W

        # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
        for communication_row in communication_copy:
            if len(communication_row) >= 8 and communication_row[7] > 0:
                total_interference_dBW = round(10 * np.log10(communication_row[7]), 2)
                communication_row[7] = total_interference_dBW
            elif len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                communication_row.append(float('-inf'))
        all_communication_copies.append(communication_copy)
    return all_communication_copies



# 计算干扰机的目标函数,单目标
def func(jammers, communication_copies):
    global a1
    global a2
    #print('jammers',jammers,'communication_copies',communication_copies)
    target_results = []
    for jammer, communication_copy in zip(jammers, communication_copies):
        P_landmax = 0
        P_airmax = 0
        Number_land = 0
        Number_air = 0
        for jammer_info in jammer:
            if jammer_info[1] == 0:  # 判断是否为地面干扰机
                if jammer_info[5] > P_landmax:
                    P_landmax = jammer_info[5]
                Number_land += 1
            elif jammer_info[1] == 1:  # 判断是否为空中干扰机
                if jammer_info[5] > P_airmax:
                    P_airmax = jammer_info[5]
                Number_air += 1

        air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')  # 非干扰通信功率4w
        land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
        T_sum = min(air_time, land_time)
        T_sum = round(T_sum, 2)

        T_sum = (T_sum - 5.58) / 59.56
        # T_sum = (T_sum -5.58)/(65.14 - 5.58)

        Number_value = 1 - (Number_land * 1 + Number_air * 2 - 32) / 32  # 空地干扰机价值比2比1                                0000000000000000000
        #Number_value = 1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 3) #空地干扰机价值比4比1
        # Number_value = (1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 4 - 32 * 1) )

        Conditions1 = check_Conditions1(communication_copy)
        Conditions2 = check_distance(communication_copy, jammer)
        #print('Conditions1',Conditions1,'Conditions2',Conditions2)

        # 限制条件判断
        if Conditions1 == 1 and Conditions2 == 1:
            Target = a1 * T_sum + a2 * Number_value
            target_results.append(Target)
            #print('Target',Target,'T_sum', T_sum, 'Number_value', Number_value,'jammer',jammer)
        else:
            Target = -100    #设置最小值，避免出现负值
            target_results.append(Target)

    # 直接将 target_results 中的元素添加到 objs 列表中
    objs = []
    for item in target_results:
        objs.append(item)
    objs = np.array(objs)
        #objs = Target
    #print('np_arrayxxxxxxxx', objs)

    return objs





class PSO:
    # 粒子内部干扰机位置、功率初始化
    def __init__(self, x_max, matrix_height, power_jammer, size):
        self.x_max = x_max
        self.height = matrix_height
        self.power = power_jammer
        self.size = size
        self.__particles = self.initialize_particles()

    def sum_place(self, x, y):
        return self.height[x, y]

    def initialize_particles(self):
        particles = []
        while len(particles) < self.size:  # 循环size次来创建粒子
            particle_jammers = []
            while len(particle_jammers) < jammer_number:  # 初始化六个干扰机
                x = np.random.randint(0, self.x_max)
                y = np.random.randint(0, self.x_max)
                selected_power = np.random.choice(self.power)
                jammer = {
                    '干扰机编号': len(particle_jammers) + 1,
                    '位置x': x,
                    '位置y': y,
                    '高度': self.sum_place(x, y),  # 使用粒子的x和y坐标来获取高度t
                    '干扰功率': selected_power,  # 功率输出值
                }
                particle_jammers.append(jammer)

                # 检查整个粒子的有效性,删除了，增加初始化的无约束性

            particles.append(particle_jammers)  # 将jammer_number个干扰机添加到粒子中

        return particles

    def get_particles(self):
        """
        返回粒子群。
        """
        return self.__particles



def position_update(x, v):
    '''更新粒子群体的位置矩阵'''
    return x + v


def update_pbest(p_best, p_best_fitness, xi, xi_fitness):
    '''判断是否需要更新粒子的历史最优位置
      PS:此处针对的都是粒子群体中的单个粒子
      pbest-该粒子当前历史最优位置
      pbest_fitness-历史最优位置对应的目标函数值
      xi-当前位置
      xi_fitness-当前位置的适应度函数值
      '''
    # 遍历粒子群，比较当前适应度与历史最优适应度
    #print('xi_fitness',xi_fitness,'p_best_fitness',p_best_fitness)
    # 在相关函数中合适的位置添加以下打印语句查看类型
    #print("xi_fitness 的类型:", type(xi_fitness))
    #print(xi_fitness.dtype)
    #print("p_best_fitness 的类型:", type(p_best_fitness))
    #print(p_best_fitness.dtype)
    for i in range(len(xi)):
        #particle_jammers = xi[i]  # 提取第i个粒子的干扰部署功率信息
        #print('xi[i]', xi[i], 'xi_fitness[i]', xi_fitness[i][0])
        #print('p_best[i]', p_best[i], 'p_best_fitness[i]', p_best_fitness[i][0])
        # 如果当前适应度更好，更新历史最优位置和适应度
        if xi_fitness[i] > p_best_fitness[i]:  # 使用xi_fitness[i][0]访问适应度值
            p_best[i] = xi[i]
            p_best_fitness[i] = xi_fitness[i]  # 更新适应度值

        #print('p_best_fitness历史最优位置更新',p_best_fitness)
    return p_best, p_best_fitness



def update_gbest(particles,p_best_fitness ,size,global_best_fitness, global_best):
    """
    计算粒子群中最大的目标函数值，并返回全局最优粒子的干扰机部署。x
    """
    # 循环遍历 particles 中的每个粒子  i_g 为第i个粒子
    for i_g in range(size):
        # 提取第 i 个粒子的干扰机信息
        jammers_in_particle = particles[i_g]
        # 调用 func 函数，并传递粒子的干扰机信息
        func_value = p_best_fitness[i_g]

        # 更新全局最优粒子及其目标函数值
        if func_value > global_best_fitness:  # 适应度值比较
            global_best_fitness = func_value
            global_best = jammers_in_particle

    return global_best_fitness, global_best

def velocity_update(v, x, p_best, g_best_x, c1, c2, w, max_val,global_best_fitness):
    '''更新每个粒子的速度向量
    输入：
    v-当前粒子群体的速度向量矩阵
    x-当前粒子群体的位置向量矩阵
    p_best-每个粒子历史最优的位置向量矩阵
    g_best_x-历史最优的粒子位置向量,size
    c1,c2-“自我认知”和“社会认知”系数
    w-惯性系数
    max_val-限制粒子的最大速度
    输出：
    更新后的粒子群体速度向量矩阵
    '''
    size = x.shape[0]  # 获取粒子个数
    r1 = np.random.random((size, 1))
    r2 = np.random.random((size, 1))
    # 向下取整
    if global_best_fitness == float('-100'):
        r2 = 0
    v_update = w * v + c1 * r1 * (p_best - x) + c2 * r2 * (g_best_x - x)
    # 四舍五入转换为整数
    v_update = np.round( v_update).astype(int)
    # 检测并修改超出自变量取值范围的值
    v_update[v_update < -1 * max_val] = -1 * max_val
    v_update[v_update > max_val] = max_val

    return v_update


def update_p_best(x, p_best):
    for i in range(len(x)):
        for j in range(len(x[i]) // 2):
            p_best[i][j][2] = x[i][2*j]
            p_best[i][j][3] = x[i][2*j+1]
    return p_best



fitness_value_list = []  # 记录搜索过程中全体最优适应度的变化
fitness_value_position_list = []  # 记录搜索过程中最优粒子位置的变化


def pso_solver2():
    '''pso主函数'''
    # PSO parameters
    dim = 2*(jammer_number - 1)  # 自变量个数  jammer_number的两倍
    size = 10  # 种群大小  粒子数数，待后期修改
    iter_num = 100  # 算法迭代最大次数
    max_val = 2000 # 限制粒子的最大速度为80 ，240，    500
    iter_count = 0  # 用于跟踪迭代次数的计数器
    c1 = 2  # 下限为1，上限为3,3-1=2
    c2 = 2
    w = 1

    # 随机初始化位置矩阵和速度矩阵
    # size和dim是外部定义的变量，分别表示粒子群的大小和每个粒子维度的大小
    v = np.random.randint(-max_val, max_val, size=(size, dim))

    particles  = generate_jammer_matrix(size)
    #print('particles',particles)


    # 获取粒子群初始化的信息列表

    # particles = pso.get_particles()
    # 每个粒子的个体的历史最优,初始化particles
    p_best = particles  ##初始化粒子个体最优部属功率信息，


    communication_copy = reprocess_interference(p_best)
    # print("将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵:", communication_copy)
    p_best_fitness = func(p_best, communication_copy)  # 计算出每个粒子的目标函数值，初始化
    #print('p_best_fitness0000000000',p_best_fitness)
    p_best_fitness = p_best_fitness.astype('float64')  ###########





    # 初始化 x 为全零数组      x为所有粒子的x，y值
    x = np.zeros((size, dim),dtype=np.int32) #限制为整数零
    # 遍历每个粒子
    for i_particle in range(size):
        # 遍历每个干扰机
        for i_jammer in range(jammer_number - 1):
            # 提取干扰机的位置x和位置y
            x_pos = particles[i_particle][i_jammer][2]
            y_pos = particles[i_particle][i_jammer][3]
            # 计算在 x 中的位置
            idx_in_x = 2 * i_jammer
            # 赋值给 x
            x[i_particle, idx_in_x] = x_pos
            x[i_particle, idx_in_x + 1] = y_pos

    p_best_x = x
    #print('x',x)   初始化所有粒子和其适应度

    # 初始化全局最优粒子及其目标函数值
    global_best_fitness = float('-100')  # 修改为负无穷大

    #初始位置信息的随机选取，不具有指导性
    global_best = p_best[0]

    global_best_fitness, global_best = update_gbest(p_best,p_best_fitness ,size,global_best_fitness, global_best)    #全局最佳适应度初始化
    #print("初始的global_best_fitness:", global_best_fitness, "初始的global_best:", global_best)
    #print('更新后的粒子的个体适应度p_best_fitness11111111', p_best_fitness)

    # 提取global_best位置x和位置y,完成global_best的初始化


    # 创建g_best_x
    g_best_x = []
    for _ in range(jammer_number - 1):  # 重复size次
        positions_x = global_best[_][2]
        positions_y = global_best[_][3]
        g_best_x.append(positions_x)
        g_best_x.append(positions_y)
    #print("g_best_x:",g_best_x)

    # 迭代过程
    for _ in range(iter_num):

        v = velocity_update(v, x, p_best_x, g_best_x, c1, c2, w, max_val,global_best_fitness)
        #print('v:',v)
        x = position_update(x, v)
        #print('x',x)


        # 定义apply_reflective_boundary函数# 设置固定边界机制，使搜索范围不会越界
        def apply_boundary(x, boundaries):
            x_min, x_max, y_min, y_max = boundaries
            new_x = []

            for row in x:
                new_row = []
                for i in range(0, len(row), 2):  # 每两个元素为一个坐标对
                    x, y = row[i], row[i + 1]  # 提取坐标对
                    # 检查x坐标
                    if x < x_min:
                        x = x_min
                    elif x > x_max:
                        x = x_max

                    # 检查y坐标
                    if y < y_min:
                        y = y_min
                    elif y > y_max:
                        y = y_max

                    # 将新的坐标对添加到新列表
                    new_row.append(x)
                    new_row.append(y)
                new_x.append(new_row)

            return new_x

        x2 = apply_boundary(x, boundaries)  # 设置固定边界机制，在函数启用后，在迭代二次后存在故障


        # 调用函数更新当前p_best
        #print('x2', x2, 'p_best', p_best)
        xi = update_p_best(x2, p_best)#更新x值,其余干扰信息不变

       # print('当前所有粒子的p_best，即xi:',xi)
        # 计算每个粒子的适应度

        communication_copy2 = reprocess_interference(xi)
        # print("将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵:", communication_copy)
        xi_fitness = func(xi, communication_copy2)  # 计算出每个粒子的目标函数值，计算每个粒子的目标适应度
        #print('当前所有粒子适应度xi_fitness:', xi_fitness)
        xi_fitness = xi_fitness.astype('float64')    ###########

        #print('更新后的粒子的个体适应度p_best_fitness', p_best_fitness)
        # 更新每个粒子的历史最优位置
        p_best, p_best_fitness = update_pbest(p_best, p_best_fitness, xi, xi_fitness)

        #print('更新后的每个粒子的个体最优干扰布局p_best', p_best)

        # 更新全局最优
        print('p_best_fitness:',p_best_fitness)
        global_best_fitness, global_best = update_gbest(p_best, p_best_fitness, size, global_best_fitness,global_best)  #
        #print('更新后的粒子的群体最佳适应度global_best_fitnesss', global_best_fitness)
        #print('更新后的粒子的群体最优干扰布局global_best', global_best)

        # 记录种群最优值的变化
        global fitness_value_list, fitness_value_position_list
        fitness_value_list.append(global_best_fitness)
        fitness_value_position_list.append(global_best)

        iter_count += 1


    return fitness_value_list, fitness_value_position_list,iter_num



#函数执行


def run_pso_with_varied_kk():
    global jammer_number
    best_fitness = float('-100')
    best_position = None
    best_kk = communication_number + 1  # 初始化为比任何可能的kk值都大的数
#为省时间，仅遍历即7,,
    for k in range(jammer_number, jammer_number + 1):
        jammer_number = k
        # 调用pso_solver2时不需要传递参数，因为它们已经是全局变量
        fitness_value_list, fitness_value_position_list, iter_num = pso_solver2()
        current_fitness = fitness_value_list[-1]
        current_position = fitness_value_position_list[-1]

        # 比较并更新最佳适应度、最佳位置和对应的kk值
        if current_fitness > best_fitness or (current_fitness == best_fitness and k < best_kk):
            best_fitness = current_fitness
            best_position = current_position
            best_kk = len(best_position)

    return best_fitness, best_position, best_kk,jammer_number



def main():

    output_file = "自适应网格粒子群算法，独立30次，空地价值2比1，场景3，侧重成本,.txt"
    with open(output_file, 'a') as file:
        for i in range(30):   #循环一次
            # 程序开始时间
            start_time = time.time()
            best_fitness, best_position, jammer_num ,start_jammer_number = run_pso_with_varied_kk()
            # 程序结束时间
            end_time = time.time()
            # 计算运行时间
            run_time = end_time - start_time
            # 输出运行时间
            file.write(f"第{i+1}次运行结果\n")
            file.write(f"Best Fitness: {[best_fitness]}\n")
            file.write(f"程序运行时间:{run_time}秒\n")
            if best_position is not None:
                file.write("对应的最佳干扰机矩阵best_jammer:\n")
                for row in best_position:
                    file.write(str(row) + "\n")
            file.write(f"符合条件的 target 总数: {jammer_num}\n\n")  #不统计
            #file.write(f"干扰机数量: {jammer_num}\n\n")
            #file.write(f"Best Position: {best_position}\n")
            #file.write(f"jammer_num: {jammer_num}\n")
            #file.write(f"start_jammer_number:{start_jammer_number}个\n")
            print(f"第{i+1}次实验的结果已保存到文件中。")


if __name__ == "__main__":
    main()


