import math
import numpy as np
import random
import time
import copy
import multiprocessing
# 空中与地面的价值比修改为2:1，采用均等适应度组合

a1 = 0.5 # 在全局作用域定义变量a1,目标函数系统工作时长的权重
a2 = 0.5 # 在全局作用域定义变量a2，目标函数干扰机成本的权重


# 通信节点相关信息矩阵
communication = [
    [1, 1, 21500, 46500, 2000, 0.6, -94.74],
    [2, 1, 39900, 25900, 2600, 0.04, -90.52],
    [3, 1, 46700, 42100, 2500, 0.55, -102.12],
    [4, 2, 17800, 41700, 5, 0.08, -95.7],
    [5, 1, 19900, 22800, 2300, 0.41, -103.54],
    [6, 1, 2600, 15200, 2000, 0.99, -107.83],
    [7, 2, 37000, 3000, 5, 0.93, -110.98],
    [8, 2, 8600, 45800, 5, 0.11, -104.16],
    [9, 2, 33900, 49400, 5, 0.34, -103.28],
    [10, 2, 42600, 28600, 5, 0.37, -91.48],
    [11, 2, 35900, 40200, 5, 0.15, -103.08],
    [12, 1, 15300, 5200, 2800, 0.55, -100.97],
    [13, 3, 1200, 49200, 2, 0.88, -110.85],
    [14, 3, 6900, 26900, 2, 0.26, -106.09],
    [15, 3, 3300, 25300, 2, 0.69, -103.46],
    [16, 3, 21800, 5900, 2, 0.65, -98.61],
    [17, 3, 5500, 5900, 2, 0.16, -102.98],
    [18, 3, 9700, 9900, 2, 0.89, -99.86],
    [19, 3, 5400, 36400, 2, 0.13, -111.49],
    [20, 3, 40100, 46200, 2, 0.58, -100.41],
    [21, 3, 35300, 7500, 2, 0.65, -103.99],
    [22, 3, 15000, 13000, 2, 0.61, -100.61],
    [23, 3, 19200, 2800, 2, 0.99, -94.94],
    [24, 3, 30000, 13500, 2, 0.02, -107.36],
    [25, 3, 3700, 5300, 2, 0.39, -103.26],
    [26, 3, 29300, 35100, 2, 0.33, -107.4],
    [27, 3, 19400, 28900, 2, 0.69, -97.51],
    [28, 3, 39600, 10000, 2, 0.97, -109.27],
    [29, 3, 11400, 20800, 2, 0.37, -101.72],
    [30, 3, 40900, 42700, 2, 0.74, -97.12],
    [31, 3, 31400, 16300, 2, 0.85, -106.55],
    [32, 3, 21500, 31700, 2, 0.28, -102.15],

]

# 干扰取链路裕量1倍
Interference_distance = [
    [0, float('-inf'), 0, 0, 0, 0, 0],
    [3, 4.77, 10, 15, 20, 20, 20],
    [6, 7.78, 10, 15, 20, 20, 20],
    [9, 9.54, 10, 15, 20, 20, 20],
    [12, 10.79, 10, 15, 20, 20, 20],
    [15, 11.76, 10, 15, 20, 20, 20],
    [18, 12.55, 10, 15, 20, 20, 20],
    [21, 13.22, 10, 15, 20, 20, 20],
    [24, 13.8, 10, 15, 20, 20, 20],
    [27, 14.31, 10, 15, 20, 20, 20],
    [30, 14.77, 10, 15, 20, 20, 20],
    [33, 15.19, 10, 15, 20, 20, 20],
    [36, 15.56, 10, 15, 20, 20, 20],
    [39, 15.91, 10, 15, 20, 20, 20],
    [42, 16.23, 10, 15, 20, 20, 20],
    [45, 16.53, 10, 15, 20, 20, 20],
    [48, 16.81, 10, 15, 20, 20, 20],
    [51, 17.08, 10, 15, 20, 20, 20],
    [54, 17.32, 10, 15, 20, 20, 20],
    [57, 17.56, 10, 15, 20, 20, 20],
    [60, 17.78, 10, 15, 20, 20, 20],
]

# 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: (
        30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


def process_matrix(global_best):  # 处理矩阵，去掉第五列元素为0的行,并重新排列
    new_matrix = []
    index = 1
    for row in global_best:
        if row[5] != 0:
            new_row = row.copy()
            new_row[0] = index
            new_matrix.append(new_row)
            index += 1
    return new_matrix


# 限制条件1相关判断（判断干信比是否大于1，这里复用之前的代码逻辑）
def check_Conditions1(communication):
    Conditions1 = 1  # 先假设所有行都满足条件，初始设为1
    for row in communication:
        if len(row) >= 8 and row[7] - row[6] <= 4.77:
            # print(f"Row {row} does not meet Condition 1")
            Conditions1 = 0
            break  # 一旦发现有一行不满足条件，就将Conditions1设为0并结束循环
    return Conditions1


# 限制条件2相关判断（判断干扰机与通信节点距离是否大于500米，这里复用之前的代码逻辑）
def check_distance(communication, jammer):
    Conditions2 = 1  # 先假设所有行都满足条件，初始设为1
    for jammer_info in jammer:
        jammer_x = jammer_info[2]
        jammer_y = jammer_info[3]
        jammer_z = jammer_info[4]
        for communication_info in communication:
            comm_x = communication_info[2]
            comm_y = communication_info[3]
            comm_z = communication_info[4]
            # 计算干扰机与通信节点之间的距离
            # distance = math.sqrt((jammer_x - comm_x) ** 2 + (jammer_y - comm_y) ** 2 + (jammer_z - comm_z) ** 2)
            distance = int(math.sqrt((jammer_x - comm_x) ** 2 + (jammer_y - comm_y) ** 2 + (jammer_z - comm_z) ** 2))

            if distance < 500:
                # print(f"Jammer {jammer_info} is too close to communication node {communication_info}")
                Conditions2 = 0
                return Conditions2
    return Conditions2


def generate_random_number_land(x_base, gap1):
    while True:

        # 在两个区间内生成随机数
        left_interval = random.randint(x_base - gap1, x_base - 350)
        right_interval = random.randint(x_base + 350, x_base + gap1)
        random_number = random.choice([left_interval, right_interval])

        # 对随机数进行边界处理
        if random_number > 50000:
            random_number = 50000
        elif random_number < 0:
            random_number = 0
        return random_number


def generate_random_number_air(x_base, gap2):
    while True:
        # 在两个区间内生成随机数
        left_interval = random.randint(x_base - gap2, x_base - 350)
        right_interval = random.randint(x_base + 350, x_base + gap2)
        random_number = random.choice([left_interval, right_interval])

        # 对随机数进行边界处理
        if random_number > 50000:
            random_number = 50000
        elif random_number < 0:
            random_number = 0
        return random_number


# 获取不重复的随机通信节点
def get_random_communication(initial_number):
    selected_communication = []
    available_indices = list(range(len(communication)))
    for _ in range(initial_number):
        if not available_indices:
            break
        random_index = random.choice(available_indices)
        selected_communication.append(communication[random_index])
        available_indices.remove(random_index)
    return selected_communication


# 生成干扰机矩阵的函数
def generate_jammer_matrix(_, initial_number,num_search_per_process):
    interference_matrix = []
    gap1 = int((32 * 1000) / initial_number)
    gap2 = int((32 * 2000) / initial_number)

    random_communication_list = get_random_communication(initial_number)

    for i2 in range(1, initial_number + 1):  # 生成30行，可根据需要更改数量                干扰机数量0000000000000000000000
        row = []
        row.append(i2)  # 序号
        # 使用random.random()生成一个0到1之间的随机数，根据其范围来确定is_airborne的值，以此调整概率
        random_num = random.random()
        # if random_num < 0.9  :
        #if random_num < max(0, 0.66 - _ /(num_search_per_process*2)):  # 空中无人机干扰价值比，和总迭代次数的增加 0.5  - _/2000  +0.4
        if random_num < max(0, 0.8 - _ / (num_search_per_process * 4)):        #4比1的实验
            # if random_num < max(0, 1 - _ / 2000):    #1 - _ / 4*1000   严格控制空中干扰机数量，几乎为0
            is_airborne = 0
        else:
            is_airborne = 1
        # 随机选取一个通信节点的索引，32个干扰机无解
        # random_communication_index = random.randint(0, len(communication) - 1)
        # random_communication = communication[random_communication_index]
        random_communication = random_communication_list[i2 - 1]

        # print('random_communication',random_communication)
        x_base = random_communication[2]
        y_base = random_communication[3]

        if is_airborne == 0:
            row.append(is_airborne)
            # 在选定通信节点x坐标的3000范围内随机生成x坐标，并确保在0到50000之间
            x_coordinate = generate_random_number_land(x_base, gap1)
            row.append(x_coordinate)
            # 在选定通信节点y坐标的3000范围内随机生成y坐标，并确保在0到50000之间
            y_coordinate = generate_random_number_land(y_base, gap1)
            row.append(y_coordinate)
            height = 3
            power_options = [30, 45, 60]
            power = random.choice(power_options)
            # power = 60
            # power = random.randint(10, 20) * 3  # 地面干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
        else:
            row.append(is_airborne)
            # 在选定通信节点x坐标的3000范围内随机生成x坐标，并确保在0到50000之间
            x_coordinate = generate_random_number_air(x_base, gap2)
            row.append(x_coordinate)
            # 在选定通信节点y坐标的3000范围内随机生成y坐标，并确保在0到50000之间
            y_coordinate = generate_random_number_air(y_base, gap2)
            row.append(y_coordinate)
            height = random.randint(400, 2000)  # 空中干扰机高度，以100为间隔，取值在300到2000之间
            power_options = [15, 30, 45]
            power = random.choice(power_options)
            # power = 45
            # power = random.randint(8, 15) * 3  # 空中干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
        row.append(height)
        row.append(power)
        interference_matrix.append(row)
        # print('interference_matrix',interference_matrix)
    return interference_matrix


# 种群数量为一
def reprocess_interference2(jammers):
    all_communication_copies = []
    communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作
    for jammer_row in jammers:
        jammer_type = jammer_row[1]
        jammer_power_W = jammer_row[5]
        jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

        for communication_row in communication_copy:
            communication_type = communication_row[1]
            x_distance = abs(jammer_row[2] - communication_row[2])
            y_distance = abs(jammer_row[3] - communication_row[3])
            z_distance = abs(jammer_row[4] - communication_row[4])

            distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
            distance = round(distance, 2)
            # distance = int(math.sqrt((x_distance ) ** 2 + (y_distance ) ** 2 + (z_distance) ** 2)) / 1000
            # print('distance00000000000',distance)
            ####

            interference_distance = None
            Gtr = None
            h_t = None
            h_r = None
            Lc_j = None

            if jammer_type == 0 and communication_type == 3:
                interference_distance = Interference_distance[jammer_power_W // 3][2]
                Gtr = 3
                h_t = 3
                h_r = 2
                Lc_j = L_two_ray(distance, h_t, h_r)
            elif jammer_type == 0 and communication_type == 2:
                interference_distance = Interference_distance[jammer_power_W // 3][3]
                Gtr = 4.5
                h_t = 3
                h_r = 5
                Lc_j = L_two_ray(distance, h_t, h_r)
            elif jammer_type == 1 and communication_type == 3:
                interference_distance = Interference_distance[jammer_power_W // 3][4]
                Gtr = 3
                Lc_j = L_sight(distance)
            elif jammer_type == 1 and communication_type == 1:
                interference_distance = Interference_distance[jammer_power_W // 3][5]
                Gtr = 4
                Lc_j = L_sight(distance)
            elif jammer_type == 0 and communication_type == 1:
                interference_distance = Interference_distance[jammer_power_W // 3][5]
                Gtr = 4
                Lc_j = L_sight(distance)
            elif jammer_type == 1 and communication_type == 2:
                interference_distance = Interference_distance[jammer_power_W // 3][6]
                Gtr = 4.5
                Lc_j = L_sight(distance)

            if interference_distance is not None and distance <= interference_distance:
                interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW != float(
                    '-inf') else 0
                if len(communication_row) < 8:
                    communication_row.append(interference_power_W + 3.16e-12)  # 环境噪声为-115dBW
                else:
                    if len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                        communication_row[7] += interference_power_W

    # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
    for communication_row in communication_copy:
        if len(communication_row) >= 8 and communication_row[7] > 0:
            total_interference_dBW = round(10 * np.log10(communication_row[7]), 2)
            communication_row[7] = total_interference_dBW
        elif len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
            communication_row.append(float('-inf'))
    all_communication_copies.append(communication_copy)
    return all_communication_copies


# 计算干扰机的目标函数,单目标,种群数量为一
def func2(jammers, communication_copies):
    global a1
    global a2
    # print('jammers',jammers,'communication_copies',communication_copies)
    target_results = []

    Conditions1 = check_Conditions12(communication_copies)
    # Conditions2 = 1
    Conditions2 = check_distance2(communication_copies, jammers)
    # print('Conditions1',Conditions1,'Conditions2',Conditions2)

    # 限制条件判断
    if Conditions1 == 1 and Conditions2 == 1:
        P_landmax = 0
        P_airmax = 0
        Number_land = 0
        Number_air = 0

        for jammer_info in jammers:
            if jammer_info[1] == 0 and jammer_info[5] != 0:  # 判断是否为地面干扰机，且功率不为0
                if jammer_info[5] > P_landmax:
                    P_landmax = jammer_info[5]
                Number_land += 1
            elif jammer_info[1] == 1 and jammer_info[5] != 0:
                if jammer_info[5] > P_airmax:
                    P_airmax = jammer_info[5]
                Number_air += 1

        air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')  # 非干扰通信功率4w
        land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
        T_sum = min(air_time, land_time)
        T_sum = round(T_sum, 2)

        T_sum = (T_sum - 5.58) / 59.56
        # T_sum = (T_sum -5.58)/(65.14 - 5.58)


        #Number_value = 1 - (Number_land * 1 + Number_air * 2 - 32) / 32   #空地干扰机价值比2比1
        Number_value = 1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 3) #空地干扰机价值比4比1     333333333333333333333333333333333333333333

        # Number_value = (1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 4 - 32 * 1) )

        # print('T_sum ',T_sum ,'Number_value',Number_value)
        Target = a1 * T_sum + a2 * Number_value
        target_results.append(Target)
        # print('Target',Target,'T_sum', T_sum, 'Number_value', Number_value,'jammer',jammers)
    else:
        Target = -100  # 设置最小值，避免出现负值
        target_results.append(Target)

    # 直接将 target_results 中的元素添加到 objs 列表中
    objs = []
    for item in target_results:
        objs.append(item)
    objs = np.array(objs)
    # objs = Target
    # print('np_arrayxxxxxxxx', objs)

    return objs


# 限制条件1相关判断（判断干信比是否大于1，这里复用之前的代码逻辑）
def check_Conditions12(communication):
    Conditions1 = 1  # 先假设所有行都满足条件，初始设为1
    # print('communication',communication)
    for row3 in communication:
        # print('row',row3)
        for row in row3:
            if len(row) >= 8 and row[7] - row[6] <= 4.77:
                # print(f"Row {row} does not meet Condition 1")
                Conditions1 = 0
                break  # 一旦发现有一行不满足条件，就将Conditions1设为0并结束循环
    return Conditions1


# 限制条件2相关判断（判断干扰机与通信节点距离是否大于500米，这里复用之前的代码逻辑）
def check_distance2(communication, jammer):
    Conditions2 = 1  # 先假设所有行都满足条件，初始设为1
    # print('jammer',jammer)
    for jammer_info in jammer:
        jammer_x = jammer_info[2]
        jammer_y = jammer_info[3]
        jammer_z = jammer_info[4]
        for communication2 in communication:
            for communication_info in communication2:
                # print('communication_info',communication_info)
                comm_x = communication_info[2]
                comm_y = communication_info[3]
                comm_z = communication_info[4]
                # 计算干扰机与通信节点之间的距离

                distance = int(
                    math.sqrt((jammer_x - comm_x) ** 2 + (jammer_y - comm_y) ** 2 + (jammer_z - comm_z) ** 2))
                if distance < 500:
                    # print(f"Jammer {jammer_info} is too close to communication node {communication_info}")
                    Conditions2 = 0
                    return Conditions2
    return Conditions2


# 新的定位置式功率调度策略3
def power_adjust2(global_best, global_best_fitness):
    power_jammer = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60]

    taboo_list = []  # 创建禁忌表，用于记录已经出现过的global_best整体状态
    taboo_list2 = []  # 创建第二个禁忌表，用于记录已经处理过的global_best[new_max_power_index]状态

    while True:
        """
            在global_best列表中挑选出基于power_jammer档位下干扰机功率最大的一组数据，
            并将其干扰功率下降一档。
            """
        max_power_index = 0
        max_power = 0
        available_interferers = []  # 用于记录当前可供选择最大功率的干扰机索引，排除禁忌表2中的干扰机
        for index, sublist in enumerate(global_best):
            current_power = sublist[-1]
            if index not in [i[0] for i in taboo_list2] and current_power in power_jammer:
                available_interferers.append(index)
                if current_power > max_power:
                    max_power = current_power
                    max_power_index = index

        if not available_interferers:  # 如果所有干扰机都在禁忌表2中，输出当前结果并跳出循环
            global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
            return global_best_fitness, global_best

        target_power_index = power_jammer.index(max_power)
        if target_power_index > 0:
            new_global_best = copy.deepcopy(global_best)
            new_global_best[max_power_index][-1] = power_jammer[target_power_index - 1]
            # print('new_global_best', new_global_best) ###加对比
            communication_copy2 = reprocess_interference2(new_global_best)
            # print('xxxxxxxxxxx')
            new_global_best_fitness = func2(new_global_best, communication_copy2)  # 计算全局最佳适应度
        else:
            # If the current power is already the minimum, break the loop
            global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
            return global_best_fitness, global_best

        # 判断新的适应度是否小于原来的适应度，如果小于，进行额外的处理逻辑
        if new_global_best_fitness < global_best_fitness:

            # global_best00 = copy.deepcopy(global_best)
            # 先将这次调整前的功率值复制给其它所有干扰机

            origin_max_power = global_best[max_power_index][-1]
            for index, sublist in enumerate(global_best):
                if index != max_power_index:
                    new_global_best[index][-1] = origin_max_power
            # 再次降低这个干扰机（最大功率对应的干扰机）的功率值
            new_max_power_index = max_power_index
            new_target_power_index = power_jammer.index(origin_max_power)
            if new_target_power_index > 0:
                new_global_best[new_max_power_index][-1] = power_jammer[new_target_power_index - 1]

                new_communication_copy2 = reprocess_interference2(new_global_best)
                # print('global_best0000000', global_best)
                new_global_best_fitness_again = func2(new_global_best, new_communication_copy2)
                # 判断再次调整后的适应度是否仍小于原来的适应度
                if new_global_best_fitness_again < global_best_fitness:
                    # 如果仍然小于，说明这是局部最优解，将此时的global_best[new_max_power_index]放入禁忌表2
                    taboo_list2.append([new_max_power_index, global_best[new_max_power_index].copy()])

                    # print('taboo_list2',taboo_list2)
                    # 不直接返回，继续循环
                    continue
                else:
                    # 如果不小于了，说明这次调整可行，更新全局最优相关信息，继续循环进行后续调整
                    global_best_fitness = new_global_best_fitness_again
                    # 判断当前global_best是否已在禁忌表中
                    if global_best in taboo_list:
                        global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
                        return global_best_fitness, global_best
                    else:
                        taboo_list.append(global_best.copy())  # 将当前global_best状态加入禁忌表（注意要复制一份添加，避免后续修改影响禁忌表内数据）
                        # print('global_best_fitness000000000000', global_best_fitness)
                        continue
            else:
                global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
                return global_best_fitness, global_best

        # Step 4: Update the global best

        # 更新全局最优粒子及其目标函数值
        if new_global_best_fitness >= global_best_fitness:  # 适应度值比较
            global_best_fitness = new_global_best_fitness
            global_best = new_global_best

    return global_best_fitness, global_best


# 空地干扰机转化调度策略
def power_adjust3(global_best, global_best_fitness):
    power_jammer = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60]

    # 将小功率空中干扰机变成地面干扰机
    for sub_list in global_best:
        if sub_list[1] == 1 and sub_list[5] <= 9:
            sub_list[1] = 0
            sub_list[4] = 3
            sub_list[5] = 30

    # 将大功率地面干扰机变成空中干扰机
    for sub_list in global_best:
        if sub_list[1] == 0 and sub_list[5] >= 57:
            sub_list[1] = 1
            sub_list[4] = 400
            sub_list[5] = 30

    taboo_list = []  # 创建禁忌表，用于记录已经出现过的global_best整体状态
    taboo_list2 = []  # 创建第二个禁忌表，用于记录已经处理过的global_best[new_max_power_index]状态

    while True:
        """
            在global_best列表中挑选出基于power_jammer档位下干扰机功率最大的一组数据，
            并将其干扰功率下降一档。
            """
        max_power_index = 0
        max_power = 0
        available_interferers = []  # 用于记录当前可供选择最大功率的干扰机索引，排除禁忌表2中的干扰机
        for index, sublist in enumerate(global_best):
            current_power = sublist[-1]
            if index not in [i[0] for i in taboo_list2] and current_power in power_jammer:
                available_interferers.append(index)
                if current_power > max_power:
                    max_power = current_power
                    max_power_index = index

        if not available_interferers:  # 如果所有干扰机都在禁忌表2中，输出当前结果并跳出循环
            global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
            return global_best_fitness, global_best

        target_power_index = power_jammer.index(max_power)
        if target_power_index > 0:
            new_global_best = copy.deepcopy(global_best)
            new_global_best[max_power_index][-1] = power_jammer[target_power_index - 1]
            # print('new_global_best', new_global_best) ###加对比
            communication_copy2 = reprocess_interference2(new_global_best)
            # print('xxxxxxxxxxx')
            new_global_best_fitness = func2(new_global_best, communication_copy2)  # 计算全局最佳适应度
        else:
            # If the current power is already the minimum, break the loop
            global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
            return global_best_fitness, global_best

        # 判断新的适应度是否小于原来的适应度，如果小于，进行额外的处理逻辑
        if new_global_best_fitness < global_best_fitness:

            origin_max_power = global_best[max_power_index][-1]
            for index, sublist in enumerate(global_best):
                if index != max_power_index:
                    new_global_best[index][-1] = origin_max_power
            # 再次降低这个干扰机（最大功率对应的干扰机）的功率值
            new_max_power_index = max_power_index
            new_target_power_index = power_jammer.index(origin_max_power)
            if new_target_power_index > 0:
                new_global_best[new_max_power_index][-1] = power_jammer[new_target_power_index - 1]

                new_communication_copy2 = reprocess_interference2(new_global_best)
                # print('global_best0000000', global_best)
                new_global_best_fitness_again = func2(new_global_best, new_communication_copy2)
                # 判断再次调整后的适应度是否仍小于原来的适应度
                if new_global_best_fitness_again < global_best_fitness:
                    # 如果仍然小于，说明这是局部最优解，将此时的global_best[new_max_power_index]放入禁忌表2
                    taboo_list2.append([new_max_power_index, global_best[new_max_power_index].copy()])

                    # print('taboo_list2',taboo_list2)
                    # 不直接返回，继续循环
                    continue
                else:
                    # 如果不小于了，说明这次调整可行，更新全局最优相关信息，继续循环进行后续调整
                    global_best_fitness = new_global_best_fitness_again
                    # 判断当前global_best是否已在禁忌表中
                    if global_best in taboo_list:
                        global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
                        return global_best_fitness, global_best
                    else:
                        taboo_list.append(global_best.copy())  # 将当前global_best状态加入禁忌表（注意要复制一份添加，避免后续修改影响禁忌表内数据）
                        # print('global_best_fitness000000000000', global_best_fitness)
                        continue
            else:
                global_best = process_matrix(global_best)  # 去除干扰功率为0的干扰机
                return global_best_fitness, global_best

        # Step 4: Update the global best

        # 更新全局最优粒子及其目标函数值
        if new_global_best_fitness >= global_best_fitness:  # 适应度值比较
            global_best_fitness = new_global_best_fitness
            global_best = new_global_best

    return global_best_fitness, global_best




def search_worker(num_search_per_process, initial_number, shared_data):
    local_Number_sum_Target2 = 0
    global a1
    global a2

    for i in range(num_search_per_process):
        # 根据不同迭代次数确定当前的initial_number倍数因子

        jammer = generate_jammer_matrix(i, initial_number, num_search_per_process)
        # print("Generated jammer matrix:", jammer)  # 打印生成的干扰机矩阵内容

        # 重新进行干扰功率计算等一系列相关操作（类似之前代码中对原始jammer的处理逻辑），获得communication_copy
        communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作
        for jammer_row in jammer:
            jammer_type = jammer_row[1]
            jammer_power_W = jammer_row[5]
            jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

            for communication_row in communication_copy:
                communication_type = communication_row[1]
                x_distance = abs(jammer_row[2] - communication_row[2])
                y_distance = abs(jammer_row[3] - communication_row[3])
                z_distance = abs(jammer_row[4] - communication_row[4])
                distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
                distance = round(distance, 2)

                interference_distance = None
                Gtr = None
                h_t = None
                h_r = None
                Lc_j = None

                if jammer_type == 0 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][2]
                    Gtr = 3
                    h_t = 3
                    h_r = 2
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 0 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][3]
                    Gtr = 4.5
                    h_t = 3
                    h_r = 5
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 1 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][4]
                    Gtr = 3
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 0 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][6]
                    Gtr = 4.5
                    Lc_j = L_sight(distance)

                if interference_distance is not None and distance <= interference_distance:
                    interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                    interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW != float(
                        '-inf') else 0
                    if len(communication_row) < 8:
                        communication_row.append(interference_power_W + 3.16e-12)
                    else:
                        if len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                            communication_row[7] += interference_power_W

        # print("打印干扰功率计算后更新的communication副本矩阵:", communication_copy)  # 打印干扰功率计算后更新的communication副本矩阵

        # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
        for communication_row in communication_copy:
            if len(communication_row) >= 8 and communication_row[7] > 0:
                total_interference_dBW = 10 * np.log10(communication_row[7])
                communication_row[7] = total_interference_dBW
            elif len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                communication_row.append(float('-inf'))

        Conditions1 = check_Conditions1(communication_copy)
        Conditions2 = check_distance(communication_copy, jammer)

        if Conditions1 == 1 and Conditions2 == 1:
            local_Number_sum_Target2 += 1
            # 计算目标函数相关参数
            P_landmax = 0
            P_airmax = 0
            Number_land = 0
            Number_air = 0
            for jammer_info in jammer:
                if jammer_info[1] == 0 and jammer_info[5] != 0:  # 判断是否为地面干扰机，且功率不为0
                    if jammer_info[5] > P_landmax:
                        P_landmax = jammer_info[5]
                    Number_land += 1
                elif jammer_info[1] == 1 and jammer_info[5] != 0:  # 判断是否为空中干扰机
                    if jammer_info[5] > P_airmax:
                        P_airmax = jammer_info[5]
                    Number_air += 1

            air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')  # 非干扰通信功率4w
            land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
            T_sum = min(air_time, land_time)
            T_sum = round(T_sum, 2)

            T_sum = (T_sum - 5.58) / 59.56
            # T_sum = (T_sum -5.58)/(65.14 - 5.58)


            #Number_value = 1 - (Number_land * 1 + Number_air * 2 - 32) / 32    #成本2比1
            Number_value = (1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 4 - 32 * 1) )        #33333333333333333333333 成本4比1

            # print('T_sum ',T_sum,'Number_value',Number_value)
            Target = a1 * T_sum + a2 * Number_value

            Target, jammer = power_adjust2(jammer, Target)  # 对群体最优进行一次定位置式功率调度
            Target, jammer = power_adjust3(jammer, Target)  # 空地干扰机转化

            if Target > shared_data['best_Target']:
                # 修改字典中的值
                shared_data['best_Target'] = Target
                shared_data['best_jammer'] = jammer  # 实时更新共享字典中的best_jammer

    return local_Number_sum_Target2



# 含干扰机初始数量调度（并行版，改进后）
def main():
    manager = multiprocessing.Manager()
    # 创建共享的字典，其中包含best_Target和best_jammer
    shared_data = manager.dict()
    shared_data['best_Target'] = float('-100')
    shared_data['best_jammer'] = None

    best_Target = float('-100')  # 初始化最大Target值为负无穷
    Number_sum_Target = 0
    initial_number = 16  # 初始设定initial_number为16
    number_upper = 33
    number_lower = 1
    initial_change = 1

    # 进程池等其他代码逻辑保持不变，但是在调用search_worker时，传递共享字典
    for iteration in range(5):
        Number_sum_Target2 = 0  # 每组新的次搜索前，初始化符合约束条件的Target总数量为0
        pool = multiprocessing.Pool(processes=5)
        results = []

        #if iteration < 2:
        if initial_change == 1:
            num_search_per_process = 10
            print('iteration', iteration)
        else:
            num_search_per_process = 100 - 10*(iteration +1)  #重点大量搜索
            iteration = 3   #最多4组

        for group in range(10):
            # 将共享字典作为参数传递
            result = pool.apply_async(search_worker, args=(num_search_per_process, initial_number, shared_data))
            # 这是一个元组形式的参数，用于向 search_worker 函数传递执行任务所需要的参数
            results.append(result)

        pool.close()
        pool.join()
        for result in results:
            local_Number_sum_Target2 = result.get()
            Number_sum_Target += local_Number_sum_Target2
            Number_sum_Target2 += local_Number_sum_Target2

        initial_change = 0
        # 根据本次100次搜索的结果，调整下一次搜索的initial_number
        if Number_sum_Target2 > 4:
            number_upper = initial_number
            initial_number = initial_number - (initial_number - number_lower) // 2
            initial_change = 1
        else:
            if Number_sum_Target2 < 1:
                number_lower = initial_number
                initial_number = initial_number + (number_upper - initial_number) // 2
                initial_change = 1

        if iteration == 3:
            break
                #####0000000000

    print("符合约束条件的Target总数量:", Number_sum_Target)
    print("最大的Target值:", shared_data['best_Target'])
    if shared_data['best_jammer'] is not None:  # 通过共享字典获取最新的best_jammer判断并输出
        print("对应的最佳干扰机矩阵best_jammer:")
        for row in shared_data['best_jammer']:
            print(row)
    else:
        print("没有找到满足条件的干扰机矩阵")

    return Number_sum_Target, shared_data['best_Target'], shared_data['best_jammer']




if __name__ == "__main__":
    with open("弹性并行随机搜索30次 场景2 空地价值4比1 侧重成本 .txt", "w") as f:
        for run_times in range(30):
            # 程序开始时间
            start_time = time.time()
            num_target, best_fitness, best_jammer_result = main()
            # 程序结束时间
            end_time = time.time()
            # 计算运行时间
            run_time = end_time - start_time
            f.write(f"第{run_times + 1}次运行结果\n")
            f.write(f"Best Fitness: {best_fitness}\n")
            f.write(f"程序运行时间:{run_time}秒\n")
            if best_jammer_result is not None:
                f.write("对应的最佳干扰机矩阵best_jammer:\n")
                for row in best_jammer_result:
                    f.write(str(row) + "\n")
            f.write(f"符合条件的 target 总数: {num_target}\n\n")









