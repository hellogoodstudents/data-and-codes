import math
import numpy as np
import random
import time

a1 = 0.5 # 在全局作用域定义变量a1,目标函数系统工作时长的权重
a2 = 0.5  # 在全局作用域定义变量a2，目标函数干扰机成本的权重


# 通信节点相关信息矩阵
communication = [
    [1, 2, 44700, 11400, 5, 0.61, -97.92],
    [2, 2, 47000, 18600, 5, 0.68, -100.42],
    [3, 1, 30600, 3700, 2200, 0.96, -99.22],
    [4, 1, 4700, 12200, 2800, 0.28, -103.94],
    [5, 1, 25600, 10000, 2400, 0.36, -99.22],
    [6, 1, 28300, 38100, 2600, 0.25, -98.41],
    [7, 1, 42300, 4600, 2300, 0.62, -96.96],
    [8, 1, 9400, 41500, 2800, 0.41, -101.49],
    [9, 1, 34300, 33500, 2600, 0.17, -98.41],
    [10, 1, 16000, 9800, 2400, 0.03, -101.52],
    [11, 1, 8900, 29600, 2300, 0.87, -104.34],
    [12, 1, 46700, 39300, 2100, 0.19, -103.12],
    [13, 3, 46200, 28300, 2, 0.21, -103.4],
    [14, 3, 19900, 200, 2, 0.4, -103.86],
    [15, 3, 34500, 7500, 2, 0.11, -96.12],
    [16, 3, 15600, 41200, 2, 0.26, -98.04],
    [17, 3, 34900, 47600, 2, 0.89, -105.27],
    [18, 3, 47600, 45200, 2, 0.85, -97.09],
    [19, 3, 8300, 2100, 2, 0.29, -104.39],
    [20, 3, 3100, 25300, 2, 0.02, -99.44],
    [21, 3, 18700, 41100, 2, 0.03, -102.68],
    [22, 3, 44400, 44900, 2, 0.06, -97.25],
    [23, 3, 42300, 43600, 2, 0.51, -97.44],
    [24, 3, 32900, 42100, 2, 0.19, -97.69],
    [25, 3, 11300, 100, 2, 0.56, -104.34],
    [26, 3, 39100, 43400, 2, 0.39, -101.51],
    [27, 3, 48400, 27700, 2, 0.49, -100.99],
    [28, 3, 47500, 28300, 2, 0.9, -100.99],
    [29, 3, 8800, 20000, 2, 0.5, -102.03],
    [30, 3, 5900, 36600, 2, 0.4, -97.72],
    [31, 3, 5000, 39500, 2, 0.48, -95.46],
    [32, 3, 400, 1300, 2, 0.79, -105.48],

]

# 干扰取链路裕量1倍
Interference_distance = [
    [0, float('-inf'), 0, 0, 0, 0, 0],
    [3, 4.77, 10, 15, 20, 20, 20],
    [6, 7.78, 10, 15, 20, 20, 20],
    [9, 9.54, 10, 15, 20, 20, 20],
    [12, 10.79, 10, 15, 20, 20, 20],
    [15, 11.76, 10, 15, 20, 20, 20],
    [18, 12.55, 10, 15, 20, 20, 20],
    [21, 13.22, 10, 15, 20, 20, 20],
    [24, 13.8, 10, 15, 20, 20, 20],
    [27, 14.31, 10, 15, 20, 20, 20],
    [30, 14.77, 10, 15, 20, 20, 20],
    [33, 15.19, 10, 15, 20, 20, 20],
    [36, 15.56, 10, 15, 20, 20, 20],
    [39, 15.91, 10, 15, 20, 20, 20],
    [42, 16.23, 10, 15, 20, 20, 20],
    [45, 16.53, 10, 15, 20, 20, 20],
    [48, 16.81, 10, 15, 20, 20, 20],
    [51, 17.08, 10, 15, 20, 20, 20],
    [54, 17.32, 10, 15, 20, 20, 20],
    [57, 17.56, 10, 15, 20, 20, 20],
    [60, 17.78, 10, 15, 20, 20, 20],
]

# 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: (
    30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


# 限制条件1相关判断（判断干信比是否大于1，这里复用之前的代码逻辑）
def check_Conditions1(communication):
    Conditions1 = 1  # 先假设所有行都满足条件，初始设为1
    for row in communication:
        if len(row) >= 8 and row[7] - row[6] <= 4.77:
            print(f"Row {row} does not meet Condition 1")
            Conditions1 = 0
            break  # 一旦发现有一行不满足条件，就将Conditions1设为0并结束循环
    return Conditions1


# 限制条件2相关判断（判断干扰机与通信节点距离是否大于500米，这里复用之前的代码逻辑）
def check_distance(communication, jammer):
    Conditions2 = 1  # 先假设所有行都满足条件，初始设为1
    for jammer_info in jammer:
        jammer_x = jammer_info[2]
        jammer_y = jammer_info[3]
        jammer_z = jammer_info[4]
        for communication_info in communication:
            comm_x = communication_info[2]
            comm_y = communication_info[3]
            comm_z = communication_info[4]
            # 计算干扰机与通信节点之间的距离
            distance = math.sqrt((jammer_x - comm_x) ** 2 + (jammer_y - comm_y) ** 2 + (jammer_z - comm_z) ** 2)
            if distance < 500:
                print(f"Jammer {jammer_info} is too close to communication node {communication_info}")
                Conditions2 = 0
                return Conditions2
    return Conditions2


# 生成干扰机矩阵的函数
def generate_jammer_matrix():
    interference_matrix = []
    for i in range(1, 33):  # 生成30行，可根据需要更改数量                干扰机数量0000000000000000000000
        row = []
        row.append(i)  # 序号
        is_airborne = random.randint(0, 1)  # 0或1，代表地面或空中干扰机
        row.append(is_airborne)
        x_coordinate = random.randint(0, 50000)   # x坐标，以100为栅格数值，取值在0到50000
        row.append(x_coordinate)
        y_coordinate = random.randint(0, 50000)   # y坐标，以100为栅格数值，取值在0到50000
        row.append(y_coordinate)
        if is_airborne == 0:
            height = 3
            power = random.randint(1, 20) * 3  # 地面干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
        else:
            height = random.randint(300, 2000)   # 空中干扰机高度，以100为间隔，取值在300到2000之间
            power = random.randint(1, 15) * 3  # 空中干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
        row.append(height)
        row.append(power)
        interference_matrix.append(row)
    return interference_matrix





# 主函数，进行100次生成、计算和判断操作
def main():
    global a1
    global a2
    best_Target = float('-100')  # 初始化最大Target值为负无穷
    best_jammer = None  # 初始化最佳干扰机矩阵为None
    Number_sum_Target = 0  # 初始化符合约束条件的Target总数量为0

    for _ in range(1000):                 ############   随机生成干扰方案的次数
        #print("Generating jammer matrix...")  # 打印开始生成干扰机矩阵信息
        jammer = generate_jammer_matrix()
        #print("Generated jammer matrix:", jammer)  # 打印生成的干扰机矩阵内容

        # 重新进行干扰功率计算等一系列相关操作（类似之前代码中对原始jammer的处理逻辑）
        communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作
        for jammer_row in jammer:
            jammer_type = jammer_row[1]
            jammer_power_W = jammer_row[5]
            jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

            for communication_row in communication_copy:
                communication_type = communication_row[1]
                x_distance = abs(jammer_row[2] - communication_row[2])
                y_distance = abs(jammer_row[3] - communication_row[3])
                z_distance = abs(jammer_row[4] - communication_row[4])
                distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
                distance = round(distance, 2)

                interference_distance = None
                Gtr = None
                h_t = None
                h_r = None
                Lc_j = None

                if jammer_type == 0 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][2]
                    Gtr = 3
                    h_t = 3
                    h_r = 2
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 0 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][3]
                    Gtr = 4.5
                    h_t = 3
                    h_r = 5
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 1 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][4]
                    Gtr = 3
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 0 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][6]
                    Gtr = 4.5
                    Lc_j = L_sight(distance)

                if interference_distance is not None and distance <= interference_distance:
                    interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                    interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW!= float('-inf') else 0
                    if len(communication_row) < 8:
                        communication_row.append(interference_power_W + 3.16e-12)
                    else:
                        if len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                            communication_row[7] += interference_power_W

        print("打印干扰功率计算后更新的communication副本矩阵:", communication_copy)  # 打印干扰功率计算后更新的communication副本矩阵

        # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
        for communication_row in communication_copy:
            if len(communication_row) >= 8 and communication_row[7] > 0:
                total_interference_dBW = 10 * np.log10(communication_row[7])
                communication_row[7] = total_interference_dBW
            elif len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                communication_row.append(float('-inf'))


        # 计算目标函数相关参数
        P_landmax = 0
        P_airmax = 0
        Number_land = 0
        Number_air = 0
        for jammer_info in jammer:
            if jammer_info[1] == 0:  # 判断是否为地面干扰机
                if jammer_info[5] > P_landmax:
                    P_landmax = jammer_info[5]
                Number_land += 1
            elif jammer_info[1] == 1:  # 判断是否为空中干扰机
                if jammer_info[5] > P_airmax:
                    P_airmax = jammer_info[5]
                Number_air += 1

        air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')  # 非干扰通信功率4w
        land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
        T_sum = min(air_time, land_time)
        T_sum = round(T_sum, 2)

        T_sum = (T_sum - 5.58) / 59.56
        # T_sum = (T_sum -5.58)/(65.14 - 5.58)

        Number_value = 1 - (Number_land * 1 + Number_air * 2 - 32) / 32  # 空地干扰机价值比2比1
        #Number_value = 1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 3) #空地干扰机价值比4比1

        # Number_value = (1 - (Number_land * 1 + Number_air * 4 - 32)/(32 * 4 - 32 * 1) )

        # print('T_sum ',T_sum ,'Number_value',Number_value)
        Target = a1 * T_sum + a2 * Number_value



        Conditions1 = check_Conditions1(communication_copy)
        Conditions2 = check_distance(communication_copy, jammer)

        if Conditions1 == 1 and Conditions2 == 1:
            Number_sum_Target += 1
            if Target > best_Target:
                best_Target = Target
                best_jammer = jammer

    print("符合约束条件的Target总数量:", Number_sum_Target)
    print("最大的Target值:", best_Target)
    if best_jammer is not None:  # 添加判断，只有当best_jammer不为None时才进行迭代输出
        print("对应的最佳干扰机矩阵best_jammer:")
        for row in best_jammer:
            print(row)
    else:
        print("没有找到满足条件的干扰机矩阵")

    return Number_sum_Target, best_Target, best_jammer


if __name__ == "__main__":
    with open("随机搜索自动30次 场景3 空地价值比2比1  侧重成本.txt", "w") as f:
        for run_times in range(30):
            # 程序开始时间
            start_time = time.time()
            num_target, best_fitness, best_jammer_result = main()
            # 程序结束时间
            end_time = time.time()
            # 计算运行时间
            run_time = end_time - start_time
            f.write(f"第{run_times + 1}次运行结果\n")
            f.write(f"Best Fitness: {[best_fitness]}\n")
            f.write(f"程序运行时间:{run_time}秒\n")
            if best_jammer_result is not None:
                f.write("对应的最佳干扰机矩阵best_jammer:\n")
                for row in best_jammer_result:
                    f.write(str(row) + "\n")
            f.write(f"符合条件的 target 总数: {num_target}\n\n")









