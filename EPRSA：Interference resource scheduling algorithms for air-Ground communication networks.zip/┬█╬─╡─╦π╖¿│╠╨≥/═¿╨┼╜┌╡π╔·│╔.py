import numpy as np
import matplotlib.pyplot as plt

# 区域大小（单位：米）
width = 50000
height = 50000
# 栅格间隔（单位：米）
grid_interval = 100

# 生成栅格化的坐标矩阵
x_grid = np.arange(0, width + grid_interval, grid_interval)
y_grid = np.arange(0, height + grid_interval, grid_interval)

# 生成空中站通信节点（确保间距大于10km，高度在2000与3000之间随机，间隔为100）
air_station1 = np.random.choice(len(x_grid), 1)[0] * grid_interval, np.random.choice(len(y_grid), 1)[0] * grid_interval, np.random.choice(np.arange(2000, 3000 + 100, 100), 1)[0]
while True:
    air_station2 = np.random.choice(len(x_grid), 1)[0] * grid_interval, np.random.choice(len(y_grid), 1)[0] * grid_interval, np.random.choice(np.arange(2000, 3000 + 100, 100), 1)[0]
    distance_air = np.sqrt((float(air_station1[0]) - float(air_station2[0])) ** 2 + (float(air_station1[1]) - float(air_station2[1])) ** 2)
    if distance_air > 10000:
        break

# 生成地面站通信节点（确保间距大于4km）
ground_stations = []
while len(ground_stations) < 10:
    new_station = np.random.choice(len(x_grid), 1)[0] * grid_interval, np.random.choice(len(y_grid), 1)[0] * grid_interval
    valid = True
    for station in ground_stations:
        distance = np.sqrt((float(new_station[0]) - float(station[0])) ** 2 + (float(new_station[1]) - float(station[1])) ** 2)
        if distance < 4000:
            valid = False
            break
    if valid:
        ground_stations.append(new_station)

# 构建通信节点矩阵，同时检查所有节点间距离是否大于500米以及新增限制条件
communication_nodes = []
# 先添加空中站通信节点
communication_nodes.append([1, 1, air_station1[0], air_station1[1], air_station1[2], np.random.rand()])
communication_nodes.append([2, 1, air_station2[0], air_station2[1], air_station2[2], np.random.rand()])

# 添加地面站通信节点
for i, station in enumerate(ground_stations):
    communication_nodes.append([i + 3, 2, station[0], station[1], 5, np.random.rand()])

# 定义计算距离的函数
def calculate_distance(terminal, nodes):
    distances = []
    for node in nodes:
        distance = np.sqrt((float(terminal[0]) - float(node[2])) ** 2 + (float(terminal[1]) - float(node[3])) ** 2)
        distances.append(distance)
    return distances

# 定义获取最近节点并检查距离限制的函数
def check_and_get_nearest(terminal, air_stations, ground_stations, air_distance_limit, ground_distance_limit):
    distances_to_air_stations = calculate_distance(terminal, air_stations)
    min_distance_to_air = min(distances_to_air_stations)
    nearest_air_station = air_stations[distances_to_air_stations.index(min_distance_to_air)]

    distances_to_ground_stations = calculate_distance(terminal, ground_stations)
    min_distance_to_ground = min(distances_to_ground_stations)
    nearest_ground_station = ground_stations[distances_to_ground_stations.index(min_distance_to_ground)]

    if min_distance_to_air < air_distance_limit or min_distance_to_ground < ground_distance_limit:
        return True
    return False

# 生成手持端通信节点（确保间距大于500米）
handheld_terminals = []
while len(handheld_terminals) < 20:
    attempt_count = 0
    while attempt_count < 1000:
        new_terminal = np.random.choice(len(x_grid), 1)[0] * grid_interval, np.random.choice(len(y_grid), 1)[0] * grid_interval
        valid = True
        for terminal in handheld_terminals:
            distance = np.sqrt((float(new_terminal[0]) - float(terminal[0])) ** 2 + (float(new_terminal[1]) - float(terminal[1])) ** 2)
            if distance < 500:
                valid = False
                break
        if valid:
            # 检查与已添加的通信节点（包括空中站和地面站）的距离是否小于500米
            distances_to_all_nodes = calculate_distance(new_terminal, communication_nodes)
            for distance in distances_to_all_nodes:
                if distance < 500:
                    valid = False
                    break

            if valid:
                # 检查距离限制并获取最近节点
                if check_and_get_nearest(new_terminal, communication_nodes[:2], communication_nodes[2:2 + len(ground_stations)], 12000, 4500):
                    valid = False
                    break

            if valid:
                handheld_terminals.append(new_terminal)
                break
        attempt_count += 1

# 将手持端通信节点添加到通信节点矩阵，并设置正确的序号
index = len(communication_nodes) + 1
for terminal in handheld_terminals:
    communication_nodes.append([index, 3, terminal[0], terminal[1], 2, np.random.rand()])
    index += 1

communication_nodes = np.array(communication_nodes)

# 将通信节点数据矩阵的数值格式化为整数（除了最后一列威胁度保留两位小数）
formatted_nodes = []
for row in communication_nodes:
    formatted_row = [int(row[0]), int(row[1]), int(row[2]), int(row[3]), int(row[4]), round(row[5], 2)]
    formatted_nodes.append(formatted_row)

# 输出通信节点数据矩阵（省略每行开头整数后面多余的小数点）
print("通信节点数据矩阵：")
for row in formatted_nodes:
    print(row)




# 绘制二维图
plt.figure()
for node in formatted_nodes:
    if node[1] == 1:
        plt.scatter(node[2], node[3], marker='*', color='red')
    elif node[1] == 2:
        plt.scatter(node[2], node[3], marker='^', color='black')
    elif node[1] == 3:
        plt.scatter(node[2], node[3], marker='o', color='blue')
plt.xlabel('X Coordinate')
plt.ylabel('Y Coordinate')
plt.title('Communication Nodes Distribution')
plt.show()

'''
[1, 1, 17500, 13000, 2700, 0.64]
[2, 1, 45000, 42500, 2800, 0.53]
[3, 2, 39700, 43000, 5, 0.84]
[4, 2, 38000, 32200, 5, 0.33]
[5, 2, 43100, 21800, 5, 0.26]
[6, 2, 12400, 2200, 5, 0.17]
[7, 2, 7100, 15400, 5, 0.92]
[8, 2, 36700, 11300, 5, 0.4]
[9, 2, 1100, 49700, 5, 0.89]
[10, 2, 2500, 3200, 5, 0.1]
[11, 2, 25800, 15000, 5, 0.3]
[12, 2, 43900, 45400, 5, 0.45]
[13, 3, 13400, 35700, 2, 0.79]
[14, 3, 17100, 30700, 2, 0.28]
[15, 3, 1600, 25800, 2, 0.18]
[16, 3, 34800, 23100, 2, 0.88]
[17, 3, 26900, 32300, 2, 0.2]
[18, 3, 5800, 27100, 2, 0.51]
[19, 3, 1000, 34100, 2, 0.39]
[20, 3, 15900, 49800, 2, 0.23]
[21, 3, 30200, 38000, 2, 0.38]
[22, 3, 6700, 7500, 2, 0.38]
[23, 3, 27700, 39400, 2, 0.9]
[24, 3, 6000, 34000, 2, 0.3]
[25, 3, 19200, 28900, 2, 0.29]
[26, 3, 10300, 26300, 2, 0.39]
[27, 3, 17300, 45100, 2, 0.33]
[28, 3, 43700, 13500, 2, 0.47]
[29, 3, 28900, 39600, 2, 0.4]
[30, 3, 48100, 6400, 2, 0.3]
[31, 3, 29100, 26900, 2, 0.41]
[32, 3, 40100, 3700, 2, 0.45]



[1, 1, 21500, 46500, 2000, 0.6],
    [2, 1, 39900, 25900, 2600, 0.04],
    [3, 1, 46700, 42100, 2500, 0.55],
    [4, 2, 17800, 41700, 5, 0.08],
    [5, 1, 19900, 22800, 2300, 0.41],
    [6, 1, 2600, 15200, 2000, 0.99],
    [7, 2, 37000, 3000, 5, 0.93],
    [8, 2, 8600, 45800, 5, 0.11],
    [9, 2, 33900, 49400, 5, 0.34],
    [10, 2, 42600, 28600, 5, 0.37],
    [11, 2, 35900, 40200, 5, 0.15],
    [12, 1, 15300, 5200, 2800, 0.55],
    [13, 3, 1200, 49200, 2, 0.88],
    [14, 3, 6900, 26900, 2, 0.26],
    [15, 3, 3300, 25300, 2, 0.69],
    [16, 3, 21800, 5900, 2, 0.65],
    [17, 3, 5500, 5900, 2, 0.16],
    [18, 3, 9700, 9900, 2, 0.89],
    [19, 3, 5400, 36400, 2, 0.13],
    [20, 3, 40100, 46200, 2, 0.58],
    [21, 3, 35300, 7500, 2, 0.65],
    [22, 3, 15000, 13000, 2, 0.61],
    [23, 3, 19200, 2800, 2, 0.99],
    [24, 3, 30000, 13500, 2, 0.02],
    [25, 3, 3700, 5300, 2, 0.39],
    [26, 3, 29300, 35100, 2, 0.33],
    [27, 3, 19400, 28900, 2, 0.69],
    [28, 3, 39600, 10000, 2, 0.97],
    [29, 3, 11400, 20800, 2, 0.37],
    [30, 3, 40900, 42700, 2, 0.74],
    [31, 3, 31400, 16300, 2, 0.85],
    [32, 3, 21500, 31700, 2, 0.28],


[1, 2, 44700, 11400, 5, 0.61, -97.92],
[2, 2, 47000, 18600, 5, 0.68, -100.42],
[3, 1, 30600, 3700, 2200, 0.96, -99.22],
[4, 1, 4700, 12200, 2800, 0.28, -103.94],
[5, 1, 25600, 10000, 2400, 0.36, -99.22],
[6, 1, 28300, 38100, 2600, 0.25, -98.41],
[7, 1, 42300, 4600, 2300, 0.62, -96.96],
[8, 1, 9400, 41500, 2800, 0.41, -101.49],
[9, 1, 34300, 33500, 2600, 0.17, -98.41],
[10, 1, 16000, 9800, 2400, 0.03, -101.52],
[11, 1, 8900, 29600, 2300, 0.87, -104.34],
[12, 1, 46700, 39300, 2100, 0.19, -103.12],
[13, 3, 46200, 28300, 2, 0.21, -103.4],
[14, 3, 19900, 200, 2, 0.4, -103.86],
[15, 3, 34500, 7500, 2, 0.11, -96.12],
[16, 3, 15600, 41200, 2, 0.26, -98.04],
[17, 3, 34900, 47600, 2, 0.89, -105.27],
[18, 3, 47600, 45200, 2, 0.85, -97.09],
[19, 3, 8300, 2100, 2, 0.29, -104.39],
[20, 3, 3100, 25300, 2, 0.02, -99.44],
[21, 3, 18700, 41100, 2, 0.03, -102.68],
[22, 3, 44400, 44900, 2, 0.06, -97.25],
[23, 3, 42300, 43600, 2, 0.51, -97.44],
[24, 3, 32900, 42100, 2, 0.19, -97.69],
[25, 3, 11300, 100, 2, 0.56, -104.34],
[26, 3, 39100, 43400, 2, 0.39, -101.51],
[27, 3, 48400, 27700, 2, 0.49, -100.99],
[28, 3, 47500, 28300, 2, 0.9, -100.99],
[29, 3, 8800, 20000, 2, 0.5, -102.03],
[30, 3, 5900, 36600, 2, 0.4, -97.72],
[31, 3, 5000, 39500, 2, 0.48, -95.46],
[32, 3, 400, 1300, 2, 0.79, -105.48],




'''