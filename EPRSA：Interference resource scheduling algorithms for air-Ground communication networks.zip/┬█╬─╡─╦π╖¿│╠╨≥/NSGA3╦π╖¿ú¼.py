import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
from itertools import combinations
from scipy.linalg import LinAlgError
from scipy.spatial.distance import cdist
import math
import random
import time

##### 输出的可行解，未归类，疑似依赖初始解，在30、40个干扰机时，搜索基本为0，远远不如随机搜索，50个干扰机时有一个解



jammer_number = 33

power_jammer = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60]


# 通信节点相关信息矩阵
communication = [
    [1, 1, 17500, 13000, 2700, 0.94, -99.15],
    [2, 1, 45000, 42500, 2800, 0.93, -89.21],
    [3, 2, 39700, 43000, 5, 0.74, -94.61],
    [4, 2, 38000, 32200, 5, 0.33, -104.73],
    [5, 2, 43100, 21800, 5, 0.26, -105.99],
    [6, 2, 12400, 2200, 5, 0.17, -104.01],
    [7, 2, 7100, 15400, 5, 0.82, -102.8],
    [8, 2, 36700, 11300, 5, 0.4, -105.9],
    [9, 2, 1100, 49700, 5, 0.69, -119.71],
    [10, 2, 2500, 3200, 5, 0.1, -104.01],
    [11, 2, 25800, 15000, 5, 0.3, -100.11],
    [12, 2, 43900, 45400, 5, 0.45, -90.17],
    [13, 3, 13400, 35700, 2, 0.79, -114.03],
    [14, 3, 17100, 30700, 2, 0.28, -110.64],
    [15, 3, 1600, 25800, 2, 0.18, -112.46],
    [16, 3, 34800, 23100, 2, 0.88, -111.26],
    [17, 3, 26900, 32300, 2, 0.2, -112.7],
    [18, 3, 5800, 27100, 2, 0.51, -111.08],
    [19, 3, 1000, 34100, 2, 0.39, -115.96],
    [20, 3, 15900, 49800, 2, 0.23, -117.42],
    [21, 3, 30200, 38000, 2, 0.38, -108.95],
    [22, 3, 6700, 7500, 2, 0.38, -105.87],
    [23, 3, 27700, 39400, 2, 0.9, -102.53],
    [24, 3, 6000, 34000, 2, 0.3, -114.51],
    [25, 3, 19200, 28900, 2, 0.29, -109.35],
    [26, 3, 10300, 26300, 2, 0.39, -108.65],
    [27, 3, 17300, 45100, 2, 0.33, -116.45],
    [28, 3, 43700, 13500, 2, 0.47, -109.5],
    [29, 3, 28900, 39600, 2, 0.4, -102.53],
    [30, 3, 48100, 6400, 2, 0.3, -116.34],
    [31, 3, 29100, 26900, 2, 0.41, -110.93],
    [32, 3, 40100, 3700, 2, 45, -111.14],

]

# 干扰取链路裕量的八分之一
Interference_distance = [
    [0, float('-inf'), 0, 0, 0, 0, 0],
    [3, 4.77, 10, 15, 20, 20, 20],
    [6, 7.78, 10, 15, 20, 20, 20],
    [9, 9.54, 10, 15, 20, 20, 20],
    [12, 10.79, 10, 15, 20, 20, 20],
    [15, 11.76, 10, 15, 20, 20, 20],
    [18, 12.55, 10, 15, 20, 20, 20],
    [21, 13.22, 10, 15, 20, 20, 20],
    [24, 13.8, 10, 15, 20, 20, 20],
    [27, 14.31, 10, 15, 20, 20, 20],
    [30, 14.77, 10, 15, 20, 20, 20],
    [33, 15.19, 10, 15, 20, 20, 20],
    [36, 15.56, 10, 15, 20, 20, 20],
    [39, 15.91, 10, 15, 20, 20, 20],
    [42, 16.23, 10, 15, 20, 20, 20],
    [45, 16.53, 10, 15, 20, 20, 20],
    [48, 16.81, 10, 15, 20, 20, 20],
    [51, 17.08, 10, 15, 20, 20, 20],
    [54, 17.32, 10, 15, 20, 20, 20],
    [57, 17.56, 10, 15, 20, 20, 20],
    [60, 17.78, 10, 15, 20, 20, 20],
]



# 视距传播损耗计算公式，其中d为干扰机与通信设备的间距，f=600
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5

# 双线传播损耗计算公式，其中d为干扰机与通信设备的间距，h_t和h_r数值依据干扰机类型与通信节点类型进行定义
L_two_ray = lambda d, h_t, h_r: (
    30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


# 限制条件1相关判断（判断干信比是否大于1，这里复用之前的代码逻辑）
def check_Conditions1(communications):
    #print('communications',communications)
    Conditions1 = 1  # 先假设所有行都满足条件，初始设为1
    for row in communications:
        #print(',row[7],row[6]',row[7],row[6])
        if row[7] == float('-inf') or row[7] - row[6] <= 4.77:
            #print(f"Row {row} does not meet Condition 1")
            Conditions1 = 0
            break  # 一旦发现有一行不满足条件，就将Conditions1设为0并结束循环
    return Conditions1


# 限制条件2相关判断（判断干扰机与通信节点距离是否大于500米，这里复用之前的代码逻辑）
def check_distance(communication, jammer):
    Conditions2 = 1  # 先假设所有行都满足条件，初始设为1
    #print('communication222222222',communication)
    #print('jammer222222', jammer)                      #########干扰机数量不对
    for jammer_info in jammer:
        jammer_x = jammer_info[2]
        jammer_y = jammer_info[3]
        jammer_z = jammer_info[4]
        for communication_info in communication:
            comm_x = communication_info[2]
            comm_y = communication_info[3]
            comm_z = communication_info[4]
            # 使用 numpy.linalg.norm 计算距离
            distance = np.linalg.norm(np.array([jammer_x - comm_x, jammer_y - comm_y, jammer_z - comm_z]))
            #print(f"Distance between jammer {jammer_info} and communication node {communication_info}: {distance} meters")
            if distance < 500:
                #print(f"Jammer {jammer_info} is too close to communication node {communication_info}")
                Conditions2 = 0
                return Conditions2
    return Conditions2


def generate_jammer_matrix(npop):
    all_interference_matrices = []
    for _ in range(npop):
        interference_matrix = []
        for i in range(1, jammer_number):  # 生成30行，可根据需要更改数量                干扰机数量jammer_number -1 0000000000000000000000
            row = []
            row.append(i)  # 序号
            is_airborne = random.randint(0, 1)  # 0或1，代表地面或空中干扰机
            row.append(is_airborne)
            x_coordinate = random.randint(0, 50000)   # x坐标，以100为栅格数值，取值在0到50000
            row.append(x_coordinate)
            y_coordinate = random.randint(0, 50000)   # y坐标，以100为栅格数值，取值在0到50000
            row.append(y_coordinate)
            if is_airborne == 0:
                height = 3
                power = random.randint(1, 20) * 3  # 地面干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
            else:
                height = random.randint(3, 2000)   # 空中干扰机高度，以100为间隔，取值在300到2000之间
                power = random.randint(1, 15) * 3  # 空中干扰机功率，取值范围3到60W，以3递增（(60 - 3) / 3 + 1 = 20种取值）
            row.append(height)
            row.append(power)
            interference_matrix.append(row)
        all_interference_matrices.append(interference_matrix)
    return all_interference_matrices


def reprocess_interference(jammers):
    all_communication_copies = []
    for jammer in jammers:
        communication_copy = [row.copy() for row in communication]  # 创建communication的副本进行操作
        for jammer_row in jammer:
            jammer_type = jammer_row[1]
            jammer_power_W = jammer_row[5]
            jammer_power_dBW = 10 * np.log10(jammer_power_W) if jammer_power_W > 0 else float('-inf')

            for communication_row in communication_copy:
                communication_type = communication_row[1]
                x_distance = abs(jammer_row[2] - communication_row[2])
                y_distance = abs(jammer_row[3] - communication_row[3])
                z_distance = abs(jammer_row[4] - communication_row[4])
                distance = np.sqrt((x_distance / 1000) ** 2 + (y_distance / 1000) ** 2 + (z_distance / 1000) ** 2)
                distance = round(distance, 2)

                interference_distance = None
                Gtr = None
                h_t = None
                h_r = None
                Lc_j = None

                if jammer_type == 0 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][2]
                    Gtr = 3
                    h_t = 3
                    h_r = 2
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 0 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][3]
                    Gtr = 4.5
                    h_t = 3
                    h_r = 5
                    Lc_j = L_two_ray(distance, h_t, h_r)
                elif jammer_type == 1 and communication_type == 3:
                    interference_distance = Interference_distance[jammer_power_W // 3][4]
                    Gtr = 3
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 0 and communication_type == 1:
                    interference_distance = Interference_distance[jammer_power_W // 3][5]
                    Gtr = 4
                    Lc_j = L_sight(distance)
                elif jammer_type == 1 and communication_type == 2:
                    interference_distance = Interference_distance[jammer_power_W // 3][6]
                    Gtr = 4.5
                    Lc_j = L_sight(distance)

                if interference_distance is not None and distance <= interference_distance:
                    interference_power_dBW = Prj(jammer_power_dBW, Gtr, Lc_j)
                    interference_power_W = 10 ** (interference_power_dBW / 10) if interference_power_dBW!= float('-inf') else 0
                    if len(communication_row) < 8:
                        communication_row.append(interference_power_W + 3.16e-12)
                    else:
                        if len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                            communication_row[7] += interference_power_W

        # 将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵，避免出现log10(0)或负数的情况
        for communication_row in communication_copy:
            if len(communication_row) >= 8 and communication_row[7] > 0:
                total_interference_dBW = round(10 * np.log10(communication_row[7]), 2)
                communication_row[7] = total_interference_dBW
            elif len(communication_row) >= 7:  # 这里添加判断，确保列表长度足够
                communication_row.append(float('-inf'))
        all_communication_copies.append(communication_copy)
    return all_communication_copies



# 计算干扰机的目标函数
def cal_obj(jammers, communication_copies,answer):
    answer = answer

    #print('jammers',jammers,'communication_copies',communication_copies)
    target_results = []
    for jammer, communication_copy in zip(jammers, communication_copies):
        P_landmax = 0
        P_airmax = 0
        Number_land = 0
        Number_air = 0
        for jammer_info in jammer:
            if jammer_info[1] == 0:  # 判断是否为地面干扰机
                if jammer_info[5] > P_landmax:
                    P_landmax = jammer_info[5]
                Number_land += 1
            elif jammer_info[1] == 1:  # 判断是否为空中干扰机
                if jammer_info[5] > P_airmax:
                    P_airmax = jammer_info[5]
                Number_air += 1

        air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')  # 非干扰通信功率4w
        land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
        T_sum = min(air_time, land_time)
        T_sum = round(T_sum, 2)

        T_sum = (T_sum - 5.58) / 59.56
        # T_sum = (T_sum -5.58)/(65.14 - 5.58)

        Number_value = 1 - (Number_land * 1 + Number_air * 2 - 32) / 32
        #Number_value = (1 - (Number_land * 1 + Number_air * 9 - 32)/(32 * 9 - 32 * 1) )  ##########################

        Conditions1 = check_Conditions1(communication_copy)
        Conditions2 = check_distance(communication_copy, jammer)
        #print('Conditions1',Conditions1,'Conditions2',Conditions2)

        # 限制条件判断
        if Conditions1 == 1 and Conditions2 == 1:
            answer += 1
            T_sum = T_sum
            Number_value = Number_value
            #print('T_sum', T_sum, 'Number_value', Number_value,'jammer',jammer)
        else:
            T_sum = -100
            Number_value = -100

        target_results.append((T_sum, Number_value))
        objs = [list(item) for item in target_results]
        objs = np.array(objs)
        #print('np_arrayxxxxxxxx', objs)
    return objs,answer



def factorial(n):
    # calculate n!
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)


def combination(n, m):
    # choose m elements from an n-length set  从n个长度的集合中选择m个元素
    if m == 0 or m == n:
        return 1
    elif m > n:
        return 0
    else:
        return factorial(n) // (factorial(m) * factorial(n - m))


def reference_points(npop, nvar):
    # 在 nvar 维度上计算近似 npop 个均匀分布的参考点
    # 这段函数的主要目的是通过一系列的计算和组合操作，生成在指定维度nvar上近似数量为npop的均匀分布的参考点。
    # 其中使用了循环和组合数学的概念来确定一些参数，并通过数学运算和数组操作来生成和调整这些参考点。

    # 初始化 h1 为 0
    h1 = 0

    # 找到满足组合数小于等于 npop 的最大 h1 值
    while combination(h1 + nvar, nvar - 1) <= npop:
        h1 += 1

    # 生成一系列组合，并进行一些处理得到初步的点
    points = np.array(list(combinations(np.arange(1, h1 + nvar), nvar - 1))) - np.arange(nvar - 1) - 1
    points = (np.concatenate((points, np.zeros((points.shape[0], 1)) + h1), axis=1) - np.concatenate((np.zeros((points.shape[0], 1)), points), axis=1)) / h1

    # 如果 h1 小于 nvar
    if h1 < nvar:
        # 初始化 h2 为 0
        h2 = 0

        # 找到满足特定条件的最大 h2 值
        while combination(h1 + nvar - 1, nvar - 1) + combination(h2 + nvar, nvar - 1) <= npop:
            h2 += 1

        # 如果 h2 大于 0
        if h2 > 0:
            # 生成临时的点
            temp_points = np.array(list(combinations(np.arange(1, h2 + nvar), nvar - 1))) - np.arange(nvar - 1) - 1
            temp_points = (np.concatenate((temp_points, np.zeros((temp_points.shape[0], 1)) + h2), axis=1) - np.concatenate((np.zeros((temp_points.shape[0], 1)), temp_points), axis=1)) / h2
            temp_points = temp_points / 2 + 1 / (2 * nvar)

            # 将临时点和之前的点合并
            points = np.concatenate((points, temp_points), axis=0)

    # 返回计算得到的参考点
    return points

##这段函数的主要目的是对给定的目标数组 objs 进行快速非支配排序，将个体分为不同的等级（前沿），
# 并返回每个个体所属的前沿列表 pfs 和对应的等级 rank 。
def nd_sort(objs):
    # 首先获取目标数组 objs 的形状，得到个体数量 npop 和目标数量 nobj
    (npop, nobj) = objs.shape

    # 创建一个全零的整数数组 n，用于存储每个个体被支配的数量
    n = np.zeros(npop, dtype=int)

    # 创建一个空列表 s，用于存储每个个体所支配的其他个体的索引
    s = []

    # 创建一个全零的整数数组 rank，用于存储每个个体的等级
    rank = np.zeros(npop, dtype=int)

    # 初始化索引 ind 为 0
    ind = 0

    # 创建一个字典 pfs，初始时 ind 对应的键值对为一个空列表
    pfs = {ind: []}

    # 遍历每个个体 i
    for i in range(npop):
        # 为每个个体 i 初始化一个空的支配列表
        s.append([])
        # 遍历除 i 之外的每个个体 j
        for j in range(npop):
            if i!= j:  # 确保不比较同一个个体
                # 初始化比较的计数
                less = equal = more = 0
                # 遍历每个目标
                for k in range(nobj):
                    if objs[i, k] < objs[j, k]:
                        less += 1
                    elif objs[i, k] == objs[j, k]:
                        equal += 1
                    else:
                        more += 1
                # 如果个体 i 不被 j 支配（less 为 0 且不是所有目标都相等）
                if less == 0 and equal!= nobj:
                    n[i] += 1  # 个体 i 的被支配数量加 1
                # 如果个体 i 支配 j（more 为 0 且不是所有目标都相等）
                elif more == 0 and equal!= nobj:
                    s[i].append(j)  # 将 j 添加到 i 的支配列表中
        # 如果个体 i 不被其他任何个体支配（被支配数量为 0）
        if n[i] == 0:
            pfs[ind].append(i)  # 将 i 添加到当前等级的前沿列表中
            rank[i] = ind  # 为 i 分配等级

    # 只要当前等级的前沿列表不为空
    while pfs[ind]:
        # 为下一个等级创建一个新的空前沿列表
        pfs[ind + 1] = []
        # 遍历当前等级的每个个体 i
        for i in pfs[ind]:
            # 遍历个体 i 所支配的每个个体 j
            for j in s[i]:
                n[j] -= 1  # 被支配数量减 1
                # 如果 j 现在不被其他个体支配
                if n[j] == 0:
                    pfs[ind + 1].append(j)  # 将 j 添加到下一个等级的前沿列表中
                    rank[j] = ind + 1  # 为 j 分配新的等级
        ind += 1  # 等级索引加 1

    # 移除最后一个空的等级前沿列表（因为循环结束时多计算了一次）
    pfs.pop(ind)

    # 返回帕累托前沿列表 pfs 和个体等级数组 rank
    return pfs, rank




# 二进制比赛选择
# 这段函数的作用是通过二进制比赛选择的方式，根据个体的等级从种群中选择一定数量的个体组成交配池。
# 在每次选择中，随机选择两个个体，比较它们的等级，等级较低（或相等）的个体被选入交配池。
def selection(pop, pc, rank, k=2):
    pop = np.array(pop)
    # 首先获取种群pop的形状，得到个体数量npop、每个个体内部的分组数量ngroup以及每个分组内的变量数量nvar
    (npop, ngroup, nvar) = pop.shape
    #print('npop', npop)
    #print('ngroup', ngroup)
    #print('nvar', nvar)

    # 计算要选择的个体数量nm ，为种群数量npop乘以交叉概率pc ，并确保其为偶数（如果不是偶数则加1）
    nm = int(npop * pc)
    nm = nm if nm % 2 == 0 else nm + 1

    # 初始化交配池mating_pool为全零数组，大小为nm行（与pop的每个个体内部分组数量相同），ngroup列（与pop的每个个体内部的分组数量相同），nvar深度（与pop的每个分组内的变量数量相同）
    mating_pool = np.zeros((nm, ngroup, nvar))


    # 进行nm次选择操作
    for i in range(nm):
        # 从npop个个体中随机选择k个不同的个体，得到它们的索引ind1和ind2
        [ind1, ind2] = np.random.choice(npop, k, replace=False)
        # print('ind1, ind2', ind1, ind2)

        # 如果个体ind1的等级rank[ind1]小于等于个体ind2的等级rank[ind2]
        if rank[ind1] <= rank[ind2]:
            # 将个体ind1放入交配池
            mating_pool[i] = pop[ind1]
        else:
            # 否则将个体ind2放入交配池
            mating_pool[i] = pop[ind2]

    mating_pool = mating_pool.astype('int32')
    #print('mating_pool', mating_pool)
    # 返回生成的交配池
    return mating_pool


def crossover(mating_pool, lb, ub, pc, eta_c,npop):
    # 获取mating_pool的形状信息，分别为个体数量noff、每个个体内部的分组数量ngroup以及每个分组内的变量数量nvar
    (noff, ngroup, nvar) = mating_pool.shape
    nm = int(noff / 2)
    # 这里需要调整parent1和parent2的提取方式，以适应三维结构
    parent1 = mating_pool[:nm, :, :]
    # print('parent1',parent1)
    # nm2 = nm +1
    parent2 = mating_pool[nm:, :, :]
    # print('parent2', parent2)
    beta = np.zeros((nm, ngroup, nvar))
    mu = np.random.random((nm, ngroup, nvar))
    flag1 = mu <= 0.5
    flag2 = ~flag1
    beta[flag1] = (2 * mu[flag1]) ** (1 / (eta_c + 1))
    beta[flag2] = (2 - 2 * mu[flag2]) ** (-1 / (eta_c + 1))

    beta = beta * (-1) ** np.random.randint(0, 2, (nm, ngroup, nvar))
    beta[np.random.random((nm, ngroup, nvar)) < 0.5] = 1

    beta[np.tile(np.random.random((nm, 1, 1)) > pc, (1, ngroup, nvar))] = 1

    offspring1 = (parent1 + parent2) / 2 + beta * (parent1 - parent2) / 2
    # print('offspring1',offspring1)

    offspring2 = (parent1 + parent2) / 2 - beta * (parent1 - parent2) / 2
    # print('offspring2', offspring2)
    offspring = np.concatenate((offspring1, offspring2), axis=0)

    #print('offspring', offspring)
    # 以下是调整后的边界处理部分
    # 先将一维的ub和lb扩展为三维，形状变为 (nm, ngroup, nvar)，使其能与offspring的维度匹配进行比较操作
    ub_expanded = np.tile(ub[np.newaxis, np.newaxis, :], (noff, ngroup, 1))
    # print('ub_expanded',ub_expanded)
    lb_expanded = np.tile(lb[np.newaxis, np.newaxis, :], (noff, ngroup, 1))
    offspring = np.min((offspring, ub_expanded), axis=0)  # 边界处理

    # 将数组元素的数据类型转换为整数类型（这里转换为int32，你也可以根据需要选择其他整数类型，如int64等）
    offspring = offspring.astype('int32')

    #print('offspring 11111  ', offspring)

    size = npop  # 设定期望的数组数量           000000000000000000000
    while True:
        # 将numpy数组转换为列表，方便后续处理重复数组相关操作
        offspring_list = offspring.tolist()
        #print("Before loop operations, offspring shape:", np.array(offspring_list).shape)  # 添加此处打印
        if len(offspring_list) <= size:
            break  # 如果当前数组数量已经小于等于期望数量，停止删除操作，直接跳出循环

        import random
        # 计算需要删除的数组数量（当前数量减去期望数量）
        num_to_delete = len(offspring_list) - size
        indices_to_delete = random.sample(range(len(offspring_list)), num_to_delete)
        indices_to_delete.sort(reverse=True)  # 从后往前删除，避免索引变化影响后续删除操作

        for index in indices_to_delete:
            del offspring_list[index]

        # 再将处理后的列表转换回numpy数组
        offspring = np.array(offspring_list)


    #print("After while loop, offspring shape:", offspring.shape)  # 添加此处打印
    # 获取new_offspring第六列数据（索引为5）
    col_five_data = offspring[:, :, 5]

    # 遍历每一个元素，检查与power_jammer中的数值是否一致，不一致则替换
    for i in range(offspring.shape[0]):
        for j in range(offspring.shape[1]):
            value = col_five_data[i, j]
            found = False
            for p in power_jammer:
                if p >= value:
                    offspring[i, j, 4] = p
                    found = True
                    break
            if not found:
                offspring[i, j, 4] = power_jammer[-1]

    #print('offspring 222222  ', offspring)
    return offspring



def mutation(pop, lb, ub, pm, eta_m):
    # polynomial mutation  多项式变异
    (npop, ngroup, nvar) = pop.shape  # 获取pop的三维形状信息
    #print('npop', npop)

    # 将lb和ub扩展为三维形状，使其能与pop进行广播运算
    lb = np.tile(lb[np.newaxis, np.newaxis, :], (npop, ngroup, 1))
    ub = np.tile(ub[np.newaxis, np.newaxis, :], (npop, ngroup, 1))
    # 由于site的生成要考虑每个分组内变量维度，需要扩展维度以匹配pop的形状
    site = np.random.random((npop, ngroup, nvar)) < pm / nvar
    mu = np.random.random((npop, ngroup, nvar))
    # 同样对delta1和delta2的计算也要考虑分组维度，进行相应修改
    delta1 = (pop - lb) / (ub - lb)
    delta2 = (ub - pop) / (ub - lb)
    temp = np.logical_and(site, mu <= 0.5)
    # 对右侧计算结果进行类型转换为int32后再执行 += 操作
    result = (ub[temp] - lb[temp]) * ((2 * mu[temp] + (1 - 2 * mu[temp]) * (1 - delta1[temp]) ** (eta_m + 1)) ** (1 / (eta_m + 1)) - 1)
    pop[temp] += result.astype('int32')
    temp = np.logical_and(site, mu > 0.5)
    result = (ub[temp] - lb[temp]) * (1 - (2 * (1 - mu[temp]) + 2 * (mu[temp] - 0.5) * (1 - delta2[temp]) ** (eta_m + 1)) ** (1 / (eta_m + 1)))
    pop[temp] += result.astype('int32')
    pop = np.min((pop, ub), axis=0)
    pop = np.max((pop, lb), axis=0)

    # 获取pop第五列数据（索引为4）
    col_five_data = pop[:, :, 4]

    # 遍历每一个元素，检查与power_jammer中的数值是否一致，不一致则替换
    for i in range(pop.shape[0]):
        for j in range(pop.shape[1]):
            value = col_five_data[i, j]
            found = False
            for p in power_jammer:
                if p >= value:
                    pop[i, j, 4] = p
                    found = True
                    break
            if not found:
                pop[i, j, 4] = power_jammer[-1]
    #print('xxx',pop)


    return pop





def environmental_selection(pop, objs, zmin, npop, V):
    #print('pop',  pop,'objs', objs,'zmin',  zmin,'npop', npop, 'V',  V)

    # NSGA-III environmental selection   NSGA-III环境选择
    pfs, rank = nd_sort(objs)
    nobj = objs.shape[1]
    selected = np.full(pop.shape[0], False)
    ind = 0
    while np.sum(selected) + len(pfs[ind]) <= npop:
        selected[pfs[ind]] = True
        ind += 1
    K = npop - np.sum(selected)

    # select the remaining K solutions   选择剩下的K个解
    objs1 = objs[selected]
    objs2 = objs[pfs[ind]]
    npop1 = objs1.shape[0]
    npop2 = objs2.shape[0]
    nv = V.shape[0]
    temp_objs = np.concatenate((objs1, objs2), axis=0)
    #print('temp_objs', temp_objs)
    t_objs = temp_objs - zmin
    #print('t_objs00000', t_objs)

    # extreme points   极端点
    extreme = np.zeros(nobj)
    w = 1e-6 + np.eye(nobj)
    for i in range(nobj):
        extreme[i] = np.argmin(np.max(t_objs / w[i], axis=1))

    # intercepts   拦截
    try:
        hyperplane = np.matmul(np.linalg.inv(t_objs[extreme.astype(int)]), np.ones((nobj, 1)))
        if np.any(hyperplane == 0):
            a = np.max(t_objs, axis=0)
        else:
            a = 1 / hyperplane
    except np.linalg.LinAlgError:
        a = np.max(t_objs, axis=0)
    # 将 a 显式转换为 float64 类型
    a = a.astype(np.float64)
    # 处理 a 中可能为零或接近零的值
    a = np.where(a == 0, 1e-10, a)
    t_objs = t_objs.astype(np.float64)
    t_objs /= a.reshape(1, nobj)

    # association  协会

    #print('t_objs', t_objs, 'V', V)
    cosine = 1 - cdist(t_objs, V, 'cosine')
    distance = np.sqrt(np.sum(t_objs ** 2, axis=1).reshape(npop1 + npop2, 1)) * np.sqrt(1 - cosine ** 2)
    dis = np.min(distance, axis=1)
    association = np.argmin(distance, axis=1)
    temp_rho = dict(Counter(association[: npop1]))
    rho = np.zeros(nv)
    for key in temp_rho.keys():
        rho[key] = temp_rho[key]

    # selection  选择
    choose = np.full(npop2, False)
    v_choose = np.full(nv, True)
    while np.sum(choose) < K:
        temp = np.where(v_choose)[0]
        jmin = np.where(rho[temp] == np.min(rho[temp]))[0]
        j = temp[np.random.choice(jmin)]
        I = np.where(np.bitwise_and(~choose, association[npop1:] == j))[0]
        if I.size > 0:
            if rho[j] == 0:
                s = np.argmin(dis[npop1 + I])
            else:
                s = np.random.randint(I.size)
            choose[I[s]] = True
            rho[j] += 1
        else:
            v_choose[j] = False
    selected[np.array(pfs[ind])[choose]] = True
    return pop[selected], objs[selected], rank[selected]







def main(npop, iter, lb, ub, nobj=2, pc=1, pm=1, eta_c=30, eta_m=20):
    """
    The main function  # 主函数
    :param npop: population size  # 种群规模
    :param iter: iteration number  # 迭代次数
    :param lb: lower bound  # 下限
    :param ub: upper bound  # 上限
    :param nobj: the dimension of objective space  # 目标空间的维度
    :param pc: crossover probability (default = 1)  # 交叉概率（默认值为 1）
    :param pm: mutation probability (default = 1)  # 变异概率（默认值为 1）
    :param eta_c: spread factor distribution index (default = 30)  # 扩展因子分布指数（默认值为 30）
    :param eta_m: perturbance factor distribution index (default = 20)  # 扰动因子分布指数（默认值为 20）
    :return:  # 返回
    """
    # Step 1. Initialization  # 步骤 1. 初始化

    answer = 0

    nvar = len(lb)  # the dimension of decision space  # 决策空间的维度

    pop = generate_jammer_matrix(npop)

    #print('pop',pop)
    communication_copy = reprocess_interference(pop)
    #print("将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵:", communication_copy)

    objs ,answer = cal_obj(pop, communication_copy,answer )  # objectives  # 目标     创建目标函数矩阵，自定义数学计算得出
    #print('objs',objs)

    V = reference_points(npop, nobj)  # reference vectors  # 参考向量
    #print('V',V)

    zmin = np.min(objs, axis=0)  # ideal points  # 理想点
    #print('zmin',zmin)

    [pfs, rank] = nd_sort(objs)  # Pareto rank  # 帕累托排序

    # Step 2. The main loop  # 步骤 2. 主循环
    for t in range(iter):


        # Step 2.1. Mating selection + crossover + mutation  # 步骤 2.1. 交配选择 + 交叉 + 变异
        mating_pool = selection(pop, pc, rank)
        #print('mating_pool',mating_pool)
        off = crossover(mating_pool, lb, ub, pc, eta_c, npop)
        #print('off111', off)
        off = mutation(off, lb, ub, pm, eta_m)
        #print('off222', off)

        # 遍历off的每一层列表（假设它有多层结构，这里对应每一组数据）限制变异的结果，符合限制条件
        for sublist in off:
            # 遍历每组数据中的每一行数据
            for row in sublist:
                if row[1] == 0:
                    row[4] = 3
                elif row[1] == 1:
                    row[4] = random.randint(300, 2000)
                    if row[5] > 45:
                        row[5] = 45
            # 更新第一列的数据，使其逐个增加
            for index in range(len(sublist)):
                sublist[index][0] = index + 1

        communication_copy2 = reprocess_interference(off)
        #print("将各通信节点收到的干扰总和转化为dBW形式并更新communication副本矩阵2222:", communication_copy2)
        off_objs , answer = cal_obj(off, communication_copy2, answer)  # objectives  # 目标     创建目标函数矩阵，自定义数学计算得出
        #print('objs', objs)
        #off_objs = cal_obj(off, nobj)


        # Step 2.2. Environmental selection  # 步骤 2.2. 环境选择
        zmin = np.min((zmin, np.min(off_objs, axis=0)), axis=0)

        #print('pop',pop,'off',off,'objs', objs, 'off_objs ',off_objs )
        pop, objs, rank = environmental_selection(np.concatenate((pop, off), axis=0), np.concatenate((objs, off_objs), axis=0), zmin, npop, V)


    # Step 3. Sort the results  # 步骤 3. 对结果排序
    pf = objs[rank == 0]
    #print("帕累托前沿上的解:")
    #for solution in pf:
        #print(solution)

    xxx = pop[0]  #输出帕累托前沿上的
    new_data = []
    for sub_list in xxx:
        new_sub_list = [str(item) for item in sub_list]  # 将每个元素转成字符串
        new_line = ', '.join(new_sub_list)  # 用逗号和空格连接成字符串
        new_data.append('[' + new_line + ']')  # 加上中括号格式


    if answer == 0:
        best_fitness = -100
        new_data = []
    else:
        best_fitness = 1


    return new_data,best_fitness,answer


 # 定义lb数组，按照期望设置具体元素值
lb = np.array([0, 0, 0, 0, 0, 3])
#print('lb', lb)
# 假设jammer_number是已经定义好的变量，这里根据你期望的ub的值来设置，
ub = np.array([jammer_number, 1, 50000, 50000, 2000, 60])


if __name__ == "__main__":
    with open("NSGA3-30次 场景1 空地价值2比1  2 .txt", "w") as f:
        for run_times in range(30):
            # 程序开始时间
            start_time = time.time()
            best_jammer_result,best_fitness,num_target = main(10, 100, lb, ub)
            # 程序结束时间
            end_time = time.time()
            # 计算运行时间
            run_time = end_time - start_time
            f.write(f"第{run_times + 1}次运行结果\n")
            f.write(f"Best Fitness: {[best_fitness]}\n")
            f.write(f"程序运行时间:{run_time}秒\n")
            if best_jammer_result is not None:
                f.write("对应的最佳干扰机矩阵best_jammer:\n")
                for row in best_jammer_result:
                    f.write(str(row) + "\n")
            f.write(f"符合条件的 target 总数: {num_target}\n\n")


