import re
import math

# 原始数据字符串，这里假设你直接复制过来的数据是这样存储的（实际中可以从文件等读取）
data_str = """

















"""



# 统计Best Fitness列表中元素不等于 -100的情况
count = 0
total_sum = 0
for result in data_str:
    if "Best Fitness" in result:
        fitness_values = result["Best Fitness"]
        count += len(fitness_values)
        total_sum += sum(fitness_values)







# 将数据字符串按实验结果分割
experiments = data_str.split("第")
experiments = [exp for exp in experiments if exp.strip()]  # 去除空字符串

# 用于存储处理后的实验结果数据（格式化为字典形式）
experiment_results = []
best_fitness_values = []
runtime_values = []
jammer_numbers = []
t_sum_values = []
number_value_values = []
for exp in experiments:
    lines = exp.strip().splitlines()
    result_dict = {}
    for line in lines:
        if "Best Fitness:" in line:
            fitness_value_str = line.split(":")[1].strip()
            try:
                # 使用eval转换为Python对象（可能是列表等）
                fitness_value_list = eval(fitness_value_str)
                if isinstance(fitness_value_list, list):
                    new_fitness_values = [v for v in fitness_value_list if v!= -100]
                    result_dict["Best Fitness"] = new_fitness_values
                    best_fitness_values.extend(new_fitness_values)
                else:
                    print(f"Best Fitness数据格式不符合预期: {fitness_value_str}")
                    continue
            except (ValueError, SyntaxError):
                print(f"无法将 {fitness_value_str} 转换为合适的数值类型，进行了跳过处理，请检查数据格式")
                continue
        elif "程序运行时间" in line:
            result_dict["运行时间"] = float(line.split(":", 1)[1].strip()[:-1])
            runtime_values.append(result_dict["运行时间"])
        elif "符合条件的 target 总数:" in line:
            target_count_line = line
    if "Best Fitness" in result_dict:
        # 处理最佳干扰机矩阵部分，提取干扰机数量
        jammer_line_index = lines.index(target_count_line) - 1
        jammer_line = lines[jammer_line_index]
        match = re.search(r'\d+', jammer_line)
        if match:
            jammer_number_str = match.group()
            try:
                jammer_number = int(jammer_number_str)
                result_dict["干扰机数量"] = jammer_number
                jammer_numbers.append(jammer_number)
            except ValueError:
                print(f"无法将干扰机数量数据 {jammer_number_str} 转换为整数，跳过处理")

        # 处理最佳干扰机矩阵部分，计算T_sum和Number_value
        best_jammer = []
        jammer_matrix_lines = lines[lines.index("对应的最佳干扰机矩阵best_jammer:") + 1:]
        for jammer_line in jammer_matrix_lines:
            parts = jammer_line.strip().split(',')
            if len(parts) == 6:
                new_parts = []
                for part in parts:
                    match = re.search(r'\d+', part)  # 查找连续的数字部分
                    if match:
                        num = int(match.group())
                        new_parts.append(num)
                    else:
                        print(f"在元素 {part} 中未找到有效数字，跳过该元素")
                best_jammer.append(new_parts)

        P_landmax = 0
        P_airmax = 0
        Number_land = 0
        Number_air = 0

        for jammer_info in best_jammer:
            if jammer_info[1] == 0:
                Number_land += 1
                if jammer_info[5] > P_landmax:
                    P_landmax = jammer_info[5]
            elif jammer_info[1] == 1:
                Number_air += 1
                if jammer_info[5] > P_airmax:
                    P_airmax = jammer_info[5]

        air_time = (0.95 * 24 * 12) / (4 + P_airmax) if P_airmax > 0 else float('inf')
        land_time = (0.95 * 24 * 20) / (4 + P_landmax) if P_landmax > 0 else float('inf')
        T_sum = min(air_time, land_time)
        T_sum = round(T_sum, 2)
        result_dict["T_sum"] = T_sum
        t_sum_values.append(T_sum)

        Number_value = Number_land * 1 + Number_air * 4 # 成本2比1 4 1
        result_dict["Number_value"] = Number_value
        number_value_values.append(Number_value)

    experiment_results.append(result_dict)

# 计算Best Fitness的平均值和标准差
if best_fitness_values:
    fitness_sum = sum(best_fitness_values)
    fitness_mean = fitness_sum / len(best_fitness_values)
    std_fitness = math.sqrt(sum((x - fitness_mean) ** 2 for x in best_fitness_values) / len(best_fitness_values))
    print("Best Fitness的平均值:", fitness_mean)
    print("Best Fitness的标准差:", std_fitness)
else:
    print("没有有效数据来计算Best Fitness的平均值和标准差")

# 计算运行时间的平均值和标准差
if runtime_values:
    runtime_sum = sum(runtime_values)
    runtime_mean = runtime_sum / len(runtime_values)
    std_runtime = math.sqrt(sum((x - runtime_mean) ** 2 for x in runtime_values) / len(runtime_values))
    print("运行时间的平均值:", runtime_mean)
    print("运行时间的标准差:", std_runtime)
else:
    print("没有有效数据来计算运行时间的平均值和标准差")

# 计算干扰机数量的平均值和标准差
if jammer_numbers:
    jammer_sum = sum(jammer_numbers)
    jammer_mean = jammer_sum / len(jammer_numbers)
    std_jammer = math.sqrt(sum((x - jammer_mean) ** 2 for x in jammer_numbers) / len(jammer_numbers))
    print("干扰机数量的平均值:", jammer_mean)
    print("干扰机数量的标准差:", std_jammer)
else:
    print("没有有效数据来计算干扰机数量的平均值和标准差")

# 计算T_sum的平均值和标准差
if t_sum_values:
    t_sum_sum = sum(t_sum_values)
    t_sum_mean = t_sum_sum / len(t_sum_values)
    std_t_sum = math.sqrt(sum((x - t_sum_mean) ** 2 for x in t_sum_values) / len(t_sum_values))
    print("T_sum的平均值:", t_sum_mean)
    print("T_sum的标准差:", std_t_sum)
else:
    print("没有有效数据来计算T_sum的平均值和标准差")

# 计算Number_value的平均值和标准差
if number_value_values:
    number_value_sum = sum(number_value_values)
    number_value_mean = number_value_sum / len(number_value_values)
    std_number_value = math.sqrt(sum((x - number_value_mean) ** 2 for x in number_value_values) / len(number_value_values))
    print("Number_value的平均值:", number_value_mean)
    print("Number_value的标准差:", std_number_value)
else:
    print("没有有效数据来计算Number_value的平均值和标准差")






# 将数据字符串按实验结果分割
experiments = data_str.split("第")
experiments = [exp for exp in experiments if exp.strip()]  # 去除空字符串

# 用于存储处理后的实验结果数据（格式化为字典形式）
experiment_results = []
all_ground_jammer_numbers = []
all_air_jammer_numbers = []
for exp in experiments:
    lines = exp.strip().splitlines()
    result_dict = {}
    ground_jammer_num = 0
    air_jammer_num = 0
    # 处理最佳干扰机矩阵部分，分别统计地面和空中干扰机数量
    best_jammer = []
    jammer_matrix_lines = lines[lines.index("对应的最佳干扰机矩阵best_jammer:") + 1:]
    for jammer_line in jammer_matrix_lines:
        parts = jammer_line.strip().split(',')
        if len(parts) == 6:
            new_parts = []
            for part in parts:
                match = re.search(r'\d+', part)  # 查找连续的数字部分
                if match:
                    num = int(match.group())
                    new_parts.append(num)
                else:
                    print(f"在元素 {part} 中未找到有效数字，跳过该元素")
            best_jammer.append(new_parts)
            if new_parts[1] == 0:
                ground_jammer_num += 1
            elif new_parts[1] == 1:
                air_jammer_num += 1

    result_dict["地面干扰机数量"] = ground_jammer_num
    result_dict["空中干扰机数量"] = air_jammer_num
    experiment_results.append(result_dict)
    all_ground_jammer_numbers.append(ground_jammer_num)
    all_air_jammer_numbers.append(air_jammer_num)

# 计算地面干扰机数量的平均值和标准差
if all_ground_jammer_numbers:
    ground_jammer_sum = sum(all_ground_jammer_numbers)
    ground_jammer_mean = ground_jammer_sum / len(all_ground_jammer_numbers)
    std_ground_jammer = math.sqrt(sum((x - ground_jammer_mean) ** 2 for x in all_ground_jammer_numbers) / len(all_ground_jammer_numbers))
    print("地面干扰机数量的平均值:", ground_jammer_mean)
    print("地面干扰机数量的标准差:", std_ground_jammer)
else:
    print("没有有效数据来计算地面干扰机数量的平均值和标准差")

# 计算空中干扰机数量的平均值和标准差
if all_air_jammer_numbers:
    air_jammer_sum = sum(all_air_jammer_numbers)
    air_jammer_mean = air_jammer_sum / len(all_air_jammer_numbers)
    std_air_jammer = math.sqrt(sum((x - air_jammer_mean) ** 2 for x in all_air_jammer_numbers) / len(all_air_jammer_numbers))
    print("空中干扰机数量的平均值:", air_jammer_mean)
    print("空中干扰机数量的标准差:", std_air_jammer)
else:
    print("没有有效数据来计算空中干扰机数量的平均值和标准差")










'''
 场景一
       [1, 1, 17500, 13000, 2700, 0.94, -99.15],
    [2, 1, 45000, 42500, 2800, 0.93, -89.21],
    [3, 2, 39700, 43000, 5, 0.74, -94.61],
    [4, 2, 38000, 32200, 5, 0.33, -104.73],
    [5, 2, 43100, 21800, 5, 0.26, -105.99],
    [6, 2, 12400, 2200, 5, 0.17, -104.01],
    [7, 2, 7100, 15400, 5, 0.82, -102.8],
    [8, 2, 36700, 11300, 5, 0.4, -105.9],
    [9, 2, 1100, 49700, 5, 0.69, -119.71],
    [10, 2, 2500, 3200, 5, 0.1, -104.01],
    [11, 2, 25800, 15000, 5, 0.3, -100.11],
    [12, 2, 43900, 45400, 5, 0.45, -90.17],
    [13, 3, 13400, 35700, 2, 0.79, -114.03],
    [14, 3, 17100, 30700, 2, 0.28, -110.64],
    [15, 3, 1600, 25800, 2, 0.18, -112.46],
    [16, 3, 34800, 23100, 2, 0.88, -111.26],
    [17, 3, 26900, 32300, 2, 0.2, -112.7],
    [18, 3, 5800, 27100, 2, 0.51, -111.08],
    [19, 3, 1000, 34100, 2, 0.39, -115.96],
    [20, 3, 15900, 49800, 2, 0.23, -117.42],
    [21, 3, 30200, 38000, 2, 0.38, -108.95],
    [22, 3, 6700, 7500, 2, 0.38, -105.87],
    [23, 3, 27700, 39400, 2, 0.9, -102.53],
    [24, 3, 6000, 34000, 2, 0.3, -114.51],
    [25, 3, 19200, 28900, 2, 0.29, -109.35],
    [26, 3, 10300, 26300, 2, 0.39, -108.65],
    [27, 3, 17300, 45100, 2, 0.33, -116.45],
    [28, 3, 43700, 13500, 2, 0.47, -109.5],
    [29, 3, 28900, 39600, 2, 0.4, -102.53],
    [30, 3, 48100, 6400, 2, 0.3, -116.34],
    [31, 3, 29100, 26900, 2, 0.41, -110.93],
    [32, 3, 40100, 3700, 2, 45, -111.14],



   场景二
        [1, 1, 21500, 46500, 2000, 0.6, -94.74],
    [2, 1, 39900, 25900, 2600, 0.04, -90.52],
    [3, 1, 46700, 42100, 2500, 0.55, -102.12],
    [4, 2, 17800, 41700, 5, 0.08, -95.7],
    [5, 1, 19900, 22800, 2300, 0.41, -103.54],
    [6, 1, 2600, 15200, 2000, 0.99, -107.83],
    [7, 2, 37000, 3000, 5, 0.93, -110.98],
    [8, 2, 8600, 45800, 5, 0.11, -104.16],
    [9, 2, 33900, 49400, 5, 0.34, -103.28],
    [10, 2, 42600, 28600, 5, 0.37, -91.48],
    [11, 2, 35900, 40200, 5, 0.15, -103.08],
    [12, 1, 15300, 5200, 2800, 0.55, -100.97],
    [13, 3, 1200, 49200, 2, 0.88, -110.85],
    [14, 3, 6900, 26900, 2, 0.26, -106.09],
    [15, 3, 3300, 25300, 2, 0.69, -103.46],
    [16, 3, 21800, 5900, 2, 0.65, -98.61],
    [17, 3, 5500, 5900, 2, 0.16, -102.98],
    [18, 3, 9700, 9900, 2, 0.89, -99.86],
    [19, 3, 5400, 36400, 2, 0.13, -111.49],
    [20, 3, 40100, 46200, 2, 0.58, -100.41],
    [21, 3, 35300, 7500, 2, 0.65, -103.99],
    [22, 3, 15000, 13000, 2, 0.61, -100.61],
    [23, 3, 19200, 2800, 2, 0.99, -94.94],
    [24, 3, 30000, 13500, 2, 0.02, -107.36],
    [25, 3, 3700, 5300, 2, 0.39, -103.26],
    [26, 3, 29300, 35100, 2, 0.33, -107.4],
    [27, 3, 19400, 28900, 2, 0.69, -97.51],
    [28, 3, 39600, 10000, 2, 0.97, -109.27],
    [29, 3, 11400, 20800, 2, 0.37, -101.72],
    [30, 3, 40900, 42700, 2, 0.74, -97.12],
    [31, 3, 31400, 16300, 2, 0.85, -106.55],
    [32, 3, 21500, 31700, 2, 0.28, -102.15],


场景三
[1, 2, 44700, 11400, 5, 0.61, -97.92],
[2, 2, 47000, 18600, 5, 0.68, -100.42],
[3, 1, 30600, 3700, 2200, 0.96, -99.22],
[4, 1, 4700, 12200, 2800, 0.28, -103.94],
[5, 1, 25600, 10000, 2400, 0.36, -99.22],
[6, 1, 28300, 38100, 2600, 0.25, -98.41],
[7, 1, 42300, 4600, 2300, 0.62, -96.96],
[8, 1, 9400, 41500, 2800, 0.41, -101.49],
[9, 1, 34300, 33500, 2600, 0.17, -98.41],
[10, 1, 16000, 9800, 2400, 0.03, -101.52],
[11, 1, 8900, 29600, 2300, 0.87, -104.34],
[12, 1, 46700, 39300, 2100, 0.19, -103.12],
[13, 3, 46200, 28300, 2, 0.21, -103.4],
[14, 3, 19900, 200, 2, 0.4, -103.86],
[15, 3, 34500, 7500, 2, 0.11, -96.12],
[16, 3, 15600, 41200, 2, 0.26, -98.04],
[17, 3, 34900, 47600, 2, 0.89, -105.27],
[18, 3, 47600, 45200, 2, 0.85, -97.09],
[19, 3, 8300, 2100, 2, 0.29, -104.39],
[20, 3, 3100, 25300, 2, 0.02, -99.44],
[21, 3, 18700, 41100, 2, 0.03, -102.68],
[22, 3, 44400, 44900, 2, 0.06, -97.25],
[23, 3, 42300, 43600, 2, 0.51, -97.44],
[24, 3, 32900, 42100, 2, 0.19, -97.69],
[25, 3, 11300, 100, 2, 0.56, -104.34],
[26, 3, 39100, 43400, 2, 0.39, -101.51],
[27, 3, 48400, 27700, 2, 0.49, -100.99],
[28, 3, 47500, 28300, 2, 0.9, -100.99],
[29, 3, 8800, 20000, 2, 0.5, -102.03],
[30, 3, 5900, 36600, 2, 0.4, -97.72],
[31, 3, 5000, 39500, 2, 0.48, -95.46],
[32, 3, 400, 1300, 2, 0.79, -105.48],




'''